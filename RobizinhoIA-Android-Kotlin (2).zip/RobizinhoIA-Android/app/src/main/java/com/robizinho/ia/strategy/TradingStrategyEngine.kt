package com.robizinho.ia.strategy

import com.robizinho.ia.model.ScreenRecognitionState
import com.robizinho.ia.model.StrategyDecision
import com.robizinho.ia.model.StrategyVotes
import com.robizinho.ia.model.StrategyWeights
import com.robizinho.ia.model.TradeDirection
import kotlin.math.abs

class TradingStrategyEngine {

    private val priceHistory = ArrayDeque<Double>(120)
    private var lastAsset: String? = null

    @Synchronized
    fun resetIfAssetChanged(asset: String) {
        if (lastAsset != asset) {
            priceHistory.clear()
            lastAsset = asset
        }
    }

    @Synchronized
    fun evaluate(
        screen: ScreenRecognitionState,
        weights: StrategyWeights,
        minConfidencePct: Int = 0
    ): StrategyDecision {
        if (screen !is ScreenRecognitionState.Identified) {
            return StrategyDecision(
                direction = TradeDirection.HOLD,
                confidence = 0.0,
                votes = StrategyVotes(
                    emaCrossoverScore = 0.0,
                    rsiMomentumScore = 0.0,
                    candleStructureScore = 0.0,
                    combinedScore = 0.0,
                    reliabilityOk = false,
                    explanation = "Dados de tela não confiáveis — operando em AGUARDAR."
                )
            )
        }

        if (screen.confidence < MIN_SCREEN_CONFIDENCE || screen.currentPrice <= 0.0) {
            return StrategyDecision(
                direction = TradeDirection.HOLD,
                confidence = 0.0,
                votes = StrategyVotes(
                    emaCrossoverScore = 0.0,
                    rsiMomentumScore = 0.0,
                    candleStructureScore = 0.0,
                    combinedScore = 0.0,
                    reliabilityOk = false,
                    explanation = "Confiança visual insuficiente (${(screen.confidence * 100).toInt()}%) ou preço inválido."
                )
            )
        }

        resetIfAssetChanged(screen.assetSymbol)
        if (priceHistory.size >= 120) {
            priceHistory.removeFirst()
        }
        priceHistory.addLast(screen.currentPrice)

        // Não operar sem histórico mínimo confiável
        if (priceHistory.size < MIN_SAMPLES) {
            return StrategyDecision(
                direction = TradeDirection.HOLD,
                confidence = 0.0,
                votes = StrategyVotes(
                    emaCrossoverScore = 0.0,
                    rsiMomentumScore = 0.0,
                    candleStructureScore = 0.0,
                    combinedScore = 0.0,
                    reliabilityOk = false,
                    explanation = "Coletando amostras confiáveis (${priceHistory.size}/$MIN_SAMPLES)."
                )
            )
        }

        val prices = priceHistory.toList()
        val emaScore = computeEmaCrossoverScore(prices)
        val emaSlope = computeEmaSlope(prices)
        val olderSlope = if (prices.size >= 8) computeEmaSlope(prices.dropLast(3)) else emaSlope
        val emaAccel = emaSlope - olderSlope
        val ema13 = ema(prices, 13)
        val prevEma13 = ema(prices.dropLast(1), 13)
        val ema13Slope = ((ema13 - prevEma13) / prices.last().coerceAtLeast(1e-6)) * 2400.0
        val ema21 = ema(prices, 21)
        val prevEma21 = ema(prices.dropLast(1), 21)
        val ema21Slope = ((ema21 - prevEma21) / prices.last().coerceAtLeast(1e-6)) * 3200.0
        val rsiValue = computeRsi(prices)
        val rsiScore = computeRsiMomentumScore(rsiValue)
        val candleScore = computeCandleStructureScore(prices, screen.chartTrendDelta)

        val combined =
            (emaScore * weights.emaWeight) +
            (rsiScore * weights.rsiWeight) +
            (candleScore * weights.candleWeight)

        // IA 1 — Análise Rápida e Precisa M1 (EMA 5/13/21 + Inclinação + RSI 9 + Estrutura)
        val ia1Direction = when {
            combined >= IA1_THRESHOLD && emaScore > 0.08 && emaSlope > 0.04 -> TradeDirection.BUY
            combined <= -IA1_THRESHOLD && emaScore < -0.08 && emaSlope < -0.04 -> TradeDirection.SELL
            else -> TradeDirection.HOLD
        }

        // Detector de Mercado Instável (Serrilhado real ou pico anormal >= 3.5x)
        val efficiencyRatio = computeEfficiencyRatio(prices)
        val whipsawFlips = countDirectionFlips(prices.takeLast(6))
        val hasSpike = detectPriceSpike(prices)
        val isUnstableMarket = (efficiencyRatio < 0.24 && whipsawFlips >= 4) || hasSpike

        var posMove = 0.0
        var negMove = 0.0
        val diStart = (prices.size - 8).coerceAtLeast(1)
        for (i in diStart until prices.size) {
            val diff = prices[i] - prices[i - 1]
            if (diff > 0.0) posMove += diff else negMove -= diff
        }
        val diTotal = posMove + negMove
        val bullDominance = if (diTotal > 0.0) posMove / diTotal else 0.5
        val bearDominance = if (diTotal > 0.0) negMove / diTotal else 0.5

        // IA 2 — Alta Assertividade: Macro EMA 21 + Dominância >= 70% + Anti-Desaceleração + ER >= 0.44
        val macroUp = prices.last() > ema21 && ema13 >= ema21 && ema21Slope > 0.03
        val macroDown = prices.last() < ema21 && ema13 <= ema21 && ema21Slope < -0.03
        val fastUp = prices.last() > ema13 && emaSlope > 0.04 && ema13Slope > 0.02
        val fastDown = prices.last() < ema13 && emaSlope < -0.04 && ema13Slope < -0.02
        val trendUp = macroUp || (efficiencyRatio >= 0.52 && fastUp)
        val trendDown = macroDown || (efficiencyRatio >= 0.52 && fastDown)

        var ia2Direction = TradeDirection.HOLD
        var ia2ConfidencePct = 0
        if (!isUnstableMarket && efficiencyRatio >= 0.44) {
            val recent4 = prices.takeLast(4)
            var upSteps = 0
            var downSteps = 0
            for (i in 1 until recent4.size) {
                if (recent4[i] >= recent4[i - 1]) upSteps++ else downSteps++
            }
            val netDelta = recent4.last() - recent4.first()
            val lastStepUp = prices.last() > prices[prices.size - 2]
            val lastStepDown = prices.last() < prices[prices.size - 2]
            val freshBull = emaAccel >= 0.01 && emaSlope >= maxOf(0.32, ema13Slope * 0.96)
            val freshBear = emaAccel <= -0.01 && emaSlope <= minOf(-0.32, ema13Slope * 0.96)

            ia2Direction = when {
                trendUp && bullDominance >= 0.70 && freshBull && emaScore > 0.12 && netDelta > 0.0 && upSteps >= 2 && lastStepUp && rsiValue >= 53.0 -> TradeDirection.BUY
                trendDown && bearDominance >= 0.70 && freshBear && emaScore < -0.12 && netDelta < 0.0 && downSteps >= 2 && lastStepDown && rsiValue <= 47.0 -> TradeDirection.SELL
                else -> TradeDirection.HOLD
            }

            if (ia2Direction != TradeDirection.HOLD) {
                val dir = if (ia2Direction == TradeDirection.BUY) 1.0 else -1.0
                val alignedEma = emaScore * dir
                val ptsTrend = when {
                    alignedEma >= 0.25 -> 30
                    alignedEma >= 0.15 -> 24
                    else -> 18
                }
                val alignedSteps = if (dir > 0) upSteps else downSteps
                val ptsConsistency = if (alignedSteps == 3) 30 else 24
                val ptsRsi = if ((dir > 0 && rsiValue >= 53.0) || (dir < 0 && rsiValue <= 47.0)) 20 else 15
                val ptsImpulse = if (candleScore * dir >= 0.12) 20 else 15
                ia2ConfidencePct = (ptsTrend + ptsConsistency + ptsRsi + ptsImpulse).coerceIn(0, 100)
            }
        }

        // IA 4 — Anti-Topo / Anti-Fundo & Aceleração Limpa
        val lastStepUp = prices.last() > prices[prices.size - 2]
        val lastStepDown = prices.last() < prices[prices.size - 2]
        val freshBull = emaAccel >= 0.01 && emaSlope >= maxOf(0.32, ema13Slope * 0.96)
        val freshBear = emaAccel <= -0.01 && emaSlope <= minOf(-0.32, ema13Slope * 0.96)
        val ia4Direction = when {
            lastStepUp && freshBull -> TradeDirection.BUY
            lastStepDown && freshBear -> TradeDirection.SELL
            else -> TradeDirection.HOLD
        }

        // IA 5 — Guardiã de Fluxo Direcional (+DI/-DI >= 70%) & Eficiência ER >= 0.44
        val ia5Direction = when {
            !isUnstableMarket && efficiencyRatio >= 0.44 && bullDominance >= 0.70 && emaSlope > 0.0 -> TradeDirection.BUY
            !isUnstableMarket && efficiencyRatio >= 0.44 && bearDominance >= 0.70 && emaSlope < 0.0 -> TradeDirection.SELL
            else -> TradeDirection.HOLD
        }

        val ia2Confirmed = ia1Direction != TradeDirection.HOLD &&
            ia2Direction == ia1Direction &&
            ia4Direction == ia1Direction &&
            ia5Direction == ia1Direction &&
            ia2ConfidencePct >= minConfidencePct

        val trendMapLabel = when {
            isUnstableMarket -> "INSTÁVEL"
            trendUp -> "TENDÊNCIA ALTA"
            trendDown -> "TENDÊNCIA BAIXA"
            else -> "LATERAL"
        }

        // IA 3 — Estrategista de Consenso das 5 IAs
        val ia3Approved = ia2Confirmed && !isUnstableMarket && efficiencyRatio >= 0.44
        val direction = if (ia3Approved) ia1Direction else TradeDirection.HOLD

        val ia3Dialogue = when {
            isUnstableMarket ->
                "5 IAs: Mercado instável, aguardar."
            ia3Approved ->
                "5 IAs unidas em $trendMapLabel ($ia2ConfidencePct%) — EXECUTAR!"
            ia1Direction != TradeDirection.HOLD && ia4Direction != ia1Direction ->
                "IA4 bloqueou topo/fundo contra ${ia1Direction.ptLabel}."
            ia1Direction != TradeDirection.HOLD && ia5Direction != ia1Direction ->
                "IA5 aguardando fluxo forte (ER=${String.format("%.2f", efficiencyRatio)})."
            ia1Direction != TradeDirection.HOLD && ia2Direction == TradeDirection.HOLD ->
                "IA1:${ia1Direction.ptLabel} | IA2:$trendMapLabel | Aguardando união."
            else ->
                "5 IAs mapeando $trendMapLabel (ER=${String.format("%.2f", efficiencyRatio)})."
        }

        val explanation = when {
            isUnstableMarket -> "Mercado instável (ER=${String.format("%.2f", efficiencyRatio)}) — AGUARDAR."
            direction == TradeDirection.BUY -> "Conselho 5 IAs COMPRAR ($ia2ConfidencePct%) · $trendMapLabel."
            direction == TradeDirection.SELL -> "Conselho 5 IAs VENDER ($ia2ConfidencePct%) · $trendMapLabel."
            else -> ia3Dialogue
        }

        return StrategyDecision(
            direction = direction,
            confidence = (ia2ConfidencePct / 100.0).coerceIn(0.0, 1.0),
            votes = StrategyVotes(
                emaCrossoverScore = emaScore,
                rsiMomentumScore = rsiScore,
                candleStructureScore = candleScore,
                combinedScore = combined,
                reliabilityOk = true,
                explanation = explanation,
                ia1Direction = ia1Direction,
                ia2Direction = ia2Direction,
                ia4Direction = ia4Direction,
                ia5Direction = ia5Direction,
                ia2ConfidencePct = ia2ConfidencePct,
                isUnstableMarket = isUnstableMarket,
                efficiencyRatio = efficiencyRatio,
                trendMapLabel = trendMapLabel,
                ia3Dialogue = ia3Dialogue
            )
        )
    }

    private fun computeEfficiencyRatio(prices: List<Double>): Double {
        val window = prices.takeLast(9)
        if (window.size < 3) return 1.0
        val netMove = abs(window.last() - window.first())
        var pathSum = 0.0
        for (i in 1 until window.size) {
            pathSum += abs(window[i] - window[i - 1])
        }
        return if (pathSum > 0.0) (netMove / pathSum).coerceIn(0.0, 1.0) else 0.0
    }

    private fun countDirectionFlips(recent: List<Double>): Int {
        if (recent.size < 3) return 0
        var flips = 0
        var prevUp = recent[1] >= recent[0]
        for (i in 2 until recent.size) {
            val curUp = recent[i] >= recent[i - 1]
            if (curUp != prevUp) flips++
            prevUp = curUp
        }
        return flips
    }

    private fun detectPriceSpike(prices: List<Double>): Boolean {
        if (prices.size < 8) return false
        val window = prices.takeLast(11)
        var sumSteps = 0.0
        for (i in 1 until window.size - 1) {
            sumSteps += abs(window[i] - window[i - 1])
        }
        val avgStep = sumSteps / (window.size - 2).coerceAtLeast(1)
        val minMeaningfulMove = prices.last() * 0.00015
        if (avgStep <= minMeaningfulMove) return false
        val lastStep = abs(window.last() - window[window.size - 2])
        return lastStep > avgStep * 3.5
    }

    private fun computeEmaSlope(prices: List<Double>): Double {
        val emaFast = ema(prices, 5)
        val prevEmaFast = ema(prices.dropLast(1), 5)
        val lastPrice = prices.last().coerceAtLeast(1e-6)
        return ((emaFast - prevEmaFast) / lastPrice) * 2400.0
    }

    private fun computeEmaCrossoverScore(prices: List<Double>): Double {
        val emaFast = ema(prices, 5)
        val emaSlow = ema(prices, 13)
        val lastPrice = prices.last().coerceAtLeast(1e-6)
        val spread = ((emaFast - emaSlow) / lastPrice) * 1500.0
        val slope = computeEmaSlope(prices)
        return (spread * 0.55 + slope * 0.45).coerceIn(-1.0, 1.0)
    }

    private fun computeRsi(prices: List<Double>, period: Int = 9): Double {
        if (prices.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0
        val start = prices.size - period
        for (i in start until prices.size) {
            val delta = prices[i] - prices[i - 1]
            if (delta >= 0) gains += delta else losses -= delta
        }
        val avgGain = gains / period
        val avgLoss = losses / period
        return if (avgLoss == 0.0) 100.0 else 100.0 - (100.0 / (1.0 + avgGain / avgLoss))
    }

    private fun computeRsiMomentumScore(rsi: Double): Double {
        return if (rsi >= 50.0) {
            ((rsi - 46.0) / 20.0).coerceIn(0.1, 1.0)
        } else {
            -((54.0 - rsi) / 20.0).coerceIn(0.1, 1.0)
        }
    }

    private fun computeCandleStructureScore(prices: List<Double>, visualTrendDelta: Double): Double {
        val recent = prices.takeLast(3)
        val microDelta = (recent.last() - recent.first()) / recent.first().coerceAtLeast(1e-6)
        val combined = (microDelta * 500.0) + visualTrendDelta
        return combined.coerceIn(-1.0, 1.0)
    }

    private fun ema(prices: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1)
        var current = prices.first()
        for (i in 1 until prices.size) {
            current = prices[i] * k + current * (1.0 - k)
        }
        return current
    }

    companion object {
        private const val MIN_SCREEN_CONFIDENCE = 0.85f
        private const val MIN_SAMPLES = 8
        private const val IA1_THRESHOLD = 0.20
    }
}
