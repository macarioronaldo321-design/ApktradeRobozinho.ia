package com.robizinho.ia.safety

import android.content.Context
import android.content.SharedPreferences
import com.robizinho.ia.model.AccountMode
import com.robizinho.ia.model.StrategyWeights
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class SafetyPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("robizinho_safety_prefs", Context.MODE_PRIVATE)

    @Synchronized
    fun resetDailyCountersIfNewDay() {
        val today = LocalDate.now().toString()
        val lastDay = prefs.getString(KEY_LAST_DAY, null)
        if (lastDay != today) {
            prefs.edit()
                .putString(KEY_LAST_DAY, today)
                .putFloat(KEY_CURRENT_DAILY_LOSS, 0f)
                .putFloat(KEY_CURRENT_DAILY_PROFIT, 0f)
                .putFloat(KEY_ACCUMULATED_RECOVERY_LOSS, 0f)
                .putInt(KEY_CURRENT_DAILY_TRADES, 0)
                .putInt(KEY_CURRENT_DAILY_WINS, 0)
                .putInt(KEY_CURRENT_DAILY_LOSSES_COUNT, 0)
                .apply()
        }
    }

    /**
     * Regra de segurança: sempre inicia em DEMO ao abrir o app ou reiniciar sessão.
     * REAL só pode ser ativado mediante autorização explícita do usuário.
     */
    fun getAccountMode(): AccountMode {
        val raw = prefs.getString(KEY_ACCOUNT_MODE, AccountMode.DEMO.name)
        val authorizedReal = prefs.getBoolean(KEY_REAL_AUTHORIZED, false)
        return if (raw == AccountMode.REAL.name && authorizedReal) {
            AccountMode.REAL
        } else {
            AccountMode.DEMO
        }
    }

    fun forceDemoMode() {
        prefs.edit()
            .putString(KEY_ACCOUNT_MODE, AccountMode.DEMO.name)
            .putBoolean(KEY_REAL_AUTHORIZED, false)
            .apply()
    }

    fun authorizeRealMode(userAcceptedRisk: Boolean) {
        if (!userAcceptedRisk) {
            forceDemoMode()
            return
        }
        prefs.edit()
            .putBoolean(KEY_REAL_AUTHORIZED, true)
            .putString(KEY_ACCOUNT_MODE, AccountMode.REAL.name)
            .apply()
    }

    fun isRealAuthorized(): Boolean = prefs.getBoolean(KEY_REAL_AUTHORIZED, false)

    fun isEmergencyStopped(): Boolean = prefs.getBoolean(KEY_EMERGENCY_STOPPED, false)

    fun setEmergencyStopped(stopped: Boolean) {
        prefs.edit()
            .putBoolean(KEY_EMERGENCY_STOPPED, stopped)
            .putBoolean(KEY_AUTO_EXECUTION_ENABLED, if (stopped) false else isAutoExecutionEnabled())
            .apply()
    }

    fun isAutoExecutionEnabled(): Boolean =
        !isEmergencyStopped() && prefs.getBoolean(KEY_AUTO_EXECUTION_ENABLED, false)

    fun setAutoExecutionEnabled(enabled: Boolean) {
        if (isEmergencyStopped() && enabled) return
        prefs.edit().putBoolean(KEY_AUTO_EXECUTION_ENABLED, enabled).apply()
    }

    fun getStakeAmount(): Double = prefs.getFloat(KEY_STAKE_AMOUNT, 0.0f).toDouble()

    fun getMaxDailyLoss(): Double = prefs.getFloat(KEY_MAX_DAILY_LOSS, 0.0f).toDouble()

    fun getMaxDailyTrades(): Int = prefs.getInt(KEY_MAX_DAILY_TRADES, 99999)

    fun getCurrentDailyLoss(): Double {
        resetDailyCountersIfNewDay()
        return prefs.getFloat(KEY_CURRENT_DAILY_LOSS, 0.0f).toDouble()
    }

    fun getCurrentDailyTrades(): Int {
        resetDailyCountersIfNewDay()
        return prefs.getInt(KEY_CURRENT_DAILY_TRADES, 0)
    }

    fun getDailyProfitGoal(): Double = prefs.getFloat(KEY_DAILY_PROFIT_GOAL, 0.0f).toDouble()

    fun getMaxStopLossCount(): Int = prefs.getInt(KEY_MAX_STOP_LOSS_COUNT, 0)

    fun isLossRecoveryEnabled(): Boolean = prefs.getBoolean(KEY_LOSS_RECOVERY_ENABLED, true)

    fun setLossRecoveryEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_LOSS_RECOVERY_ENABLED, enabled).apply()
    }

    fun getCurrentDailyProfit(): Double {
        resetDailyCountersIfNewDay()
        return prefs.getFloat(KEY_CURRENT_DAILY_PROFIT, 0.0f).toDouble()
    }

    fun getAccumulatedRecoveryLoss(): Double {
        resetDailyCountersIfNewDay()
        return prefs.getFloat(KEY_ACCUMULATED_RECOVERY_LOSS, 0.0f).toDouble()
    }

    fun computeEffectiveStake(): Double {
        val base = getStakeAmount()
        if (base <= 0.0) return 0.0
        if (!isLossRecoveryEnabled()) return base
        val toRecover = getAccumulatedRecoveryLoss()
        if (toRecover <= 0.0) return base
        val maxLoss = getMaxDailyLoss()
        val maxCap = if (maxLoss > 0.0) {
            minOf(base * 3.0, (maxLoss - getCurrentDailyLoss()).coerceAtLeast(base))
        } else {
            base * 3.0
        }
        val ideal = kotlin.math.ceil((toRecover + base * 0.5) / 0.85)
        return ideal.coerceIn(base, maxCap)
    }

    fun saveLimits(
        stake: Double,
        maxLoss: Double,
        maxTrades: Int,
        officialApiUrl: String,
        dailyProfitGoal: Double = getDailyProfitGoal(),
        maxStopLossCount: Int = getMaxStopLossCount(),
        lossRecoveryEnabled: Boolean = isLossRecoveryEnabled()
    ) {
        prefs.edit()
            .putFloat(KEY_STAKE_AMOUNT, stake.coerceAtLeast(0.0).toFloat())
            .putFloat(KEY_MAX_DAILY_LOSS, maxLoss.coerceAtLeast(0.0).toFloat())
            .putInt(KEY_MAX_DAILY_TRADES, maxTrades.coerceAtLeast(1))
            .putFloat(KEY_DAILY_PROFIT_GOAL, dailyProfitGoal.coerceAtLeast(0.0).toFloat())
            .putInt(KEY_MAX_STOP_LOSS_COUNT, maxStopLossCount.coerceAtLeast(0))
            .putBoolean(KEY_LOSS_RECOVERY_ENABLED, lossRecoveryEnabled)
            .putString(KEY_OFFICIAL_API_URL, officialApiUrl.trim())
            .apply()
    }

    fun getOfficialApiUrl(): String = prefs.getString(KEY_OFFICIAL_API_URL, "") ?: ""

    fun getOfficialApiToken(): String = prefs.getString(KEY_OFFICIAL_API_TOKEN, "") ?: ""

    fun saveOfficialApiToken(token: String) {
        prefs.edit().putString(KEY_OFFICIAL_API_TOKEN, token.trim()).apply()
    }

    fun isAccessibilityAutomationAllowedByUser(): Boolean =
        prefs.getBoolean(KEY_ALLOW_ACCESSIBILITY_AUTOMATION, false)

    fun setAccessibilityAutomationAllowedByUser(allowed: Boolean) {
        prefs.edit().putBoolean(KEY_ALLOW_ACCESSIBILITY_AUTOMATION, allowed).apply()
    }

    fun getCurrentDailyWins(): Int {
        resetDailyCountersIfNewDay()
        return prefs.getInt(KEY_CURRENT_DAILY_WINS, 0)
    }

    fun getCurrentDailyLossesCount(): Int {
        resetDailyCountersIfNewDay()
        return prefs.getInt(KEY_CURRENT_DAILY_LOSSES_COUNT, 0)
    }

    @Synchronized
    fun recordAcceptedTrade(lossDelta: Double = 0.0, won: Boolean? = null, profitDelta: Double = 0.0) {
        resetDailyCountersIfNewDay()
        val trades = getCurrentDailyTrades() + 1
        val loss = (getCurrentDailyLoss() + lossDelta.coerceAtLeast(0.0)).toFloat()
        val netProfit = (getCurrentDailyProfit() + profitDelta).toFloat()
        val editor = prefs.edit()
            .putInt(KEY_CURRENT_DAILY_TRADES, trades)
            .putFloat(KEY_CURRENT_DAILY_LOSS, loss)
            .putFloat(KEY_CURRENT_DAILY_PROFIT, netProfit)
        if (won == true) {
            editor.putInt(KEY_CURRENT_DAILY_WINS, getCurrentDailyWins() + 1)
            val remainingRecovery = (getAccumulatedRecoveryLoss() - profitDelta.coerceAtLeast(0.0)).coerceAtLeast(0.0)
            editor.putFloat(KEY_ACCUMULATED_RECOVERY_LOSS, remainingRecovery.toFloat())
        } else if (won == false) {
            editor.putInt(KEY_CURRENT_DAILY_LOSSES_COUNT, getCurrentDailyLossesCount() + 1)
            val nextRecovery = getAccumulatedRecoveryLoss() + lossDelta.coerceAtLeast(0.0)
            editor.putFloat(KEY_ACCUMULATED_RECOVERY_LOSS, nextRecovery.toFloat())
        }
        editor.apply()
    }

    @Synchronized
    fun appendTradeHistory(time: String, asset: String, direction: String, status: String, detail: String) {
        val currentRaw = prefs.getString(KEY_TRADE_HISTORY, "[]") ?: "[]"
        val arr = runCatching { JSONArray(currentRaw) }.getOrElse { JSONArray() }
        val entry = JSONObject().apply {
            put("time", time)
            put("asset", asset)
            put("direction", direction)
            put("status", status)
            put("detail", detail)
        }
        val updated = JSONArray()
        updated.put(entry)
        val maxKeep = 99
        for (i in 0 until minOf(arr.length(), maxKeep)) {
            updated.put(arr.get(i))
        }
        prefs.edit().putString(KEY_TRADE_HISTORY, updated.toString()).apply()
    }

    fun getTradeHistoryLines(limit: Int = 20): List<String> {
        val currentRaw = prefs.getString(KEY_TRADE_HISTORY, "[]") ?: "[]"
        val arr = runCatching { JSONArray(currentRaw) }.getOrElse { JSONArray() }
        val lines = mutableListOf<String>()
        for (i in 0 until minOf(arr.length(), limit)) {
            val obj = arr.optJSONObject(i) ?: continue
            lines.add(
                "${obj.optString("time")} · ${obj.optString("direction")} ${obj.optString("asset")} [${obj.optString("status")}] ${obj.optString("detail")}"
            )
        }
        return lines
    }

    @Synchronized
    fun recordDemoOutcomeAndUpdateWeights(
        emaContribution: Double,
        rsiContribution: Double,
        candleContribution: Double,
        won: Boolean
    ): StrategyWeights {
        val current = getStrategyWeights()
        val lr = 0.05
        val sign = if (won) 1.0 else -1.0

        val rawEma = (current.emaWeight + lr * sign * kotlin.math.abs(emaContribution)).coerceIn(0.15, 0.70)
        val rawRsi = (current.rsiWeight + lr * sign * kotlin.math.abs(rsiContribution)).coerceIn(0.15, 0.70)
        val rawCandle = (current.candleWeight + lr * sign * kotlin.math.abs(candleContribution)).coerceIn(0.15, 0.70)
        val sum = rawEma + rawRsi + rawCandle

        val updated = StrategyWeights(
            emaWeight = rawEma / sum,
            rsiWeight = rawRsi / sum,
            candleWeight = rawCandle / sum,
            demoSampleCount = current.demoSampleCount + 1
        )

        prefs.edit()
            .putFloat(KEY_W_EMA, updated.emaWeight.toFloat())
            .putFloat(KEY_W_RSI, updated.rsiWeight.toFloat())
            .putFloat(KEY_W_CANDLE, updated.candleWeight.toFloat())
            .putInt(KEY_DEMO_SAMPLES, updated.demoSampleCount)
            .apply()

        return updated
    }

    fun getStrategyWeights(): StrategyWeights {
        return StrategyWeights(
            emaWeight = prefs.getFloat(KEY_W_EMA, 0.40f).toDouble(),
            rsiWeight = prefs.getFloat(KEY_W_RSI, 0.30f).toDouble(),
            candleWeight = prefs.getFloat(KEY_W_CANDLE, 0.30f).toDouble(),
            demoSampleCount = prefs.getInt(KEY_DEMO_SAMPLES, 0)
        )
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs.edit()
            .putInt(KEY_OVERLAY_X, x)
            .putInt(KEY_OVERLAY_Y, y)
            .apply()
    }

    fun getOverlayX(): Int = prefs.getInt(KEY_OVERLAY_X, 24)

    fun getOverlayY(): Int = prefs.getInt(KEY_OVERLAY_Y, 220)

    fun isOverlayPinned(): Boolean = prefs.getBoolean(KEY_OVERLAY_PINNED, false)

    fun setOverlayPinned(pinned: Boolean) {
        prefs.edit().putBoolean(KEY_OVERLAY_PINNED, pinned).apply()
    }

    fun getOperationDurationSeconds(): Int = prefs.getInt(KEY_OPERATION_DURATION_SEC, 60)

    fun saveOperationDurationSeconds(seconds: Int) {
        prefs.edit().putInt(KEY_OPERATION_DURATION_SEC, seconds.coerceIn(60, 3600)).apply()
    }

    fun getMinConfidencePct(): Int = prefs.getInt(KEY_MIN_CONFIDENCE_PCT, 0)

    fun saveMinConfidencePct(pct: Int) {
        prefs.edit().putInt(KEY_MIN_CONFIDENCE_PCT, pct.coerceIn(0, 99)).apply()
    }

    fun getPreferredBrokerPackage(): String = prefs.getString(KEY_PREFERRED_BROKER_PKG, "") ?: ""

    fun setPreferredBrokerPackage(pkg: String) {
        prefs.edit().putString(KEY_PREFERRED_BROKER_PKG, pkg.trim()).apply()
    }

    companion object {
        private const val KEY_LAST_DAY = "last_day"
        private const val KEY_ACCOUNT_MODE = "account_mode"
        private const val KEY_REAL_AUTHORIZED = "real_authorized"
        private const val KEY_EMERGENCY_STOPPED = "emergency_stopped"
        private const val KEY_AUTO_EXECUTION_ENABLED = "auto_execution_enabled"
        private const val KEY_STAKE_AMOUNT = "stake_amount"
        private const val KEY_MAX_DAILY_LOSS = "max_daily_loss"
        private const val KEY_MAX_DAILY_TRADES = "max_daily_trades"
        private const val KEY_CURRENT_DAILY_LOSS = "current_daily_loss"
        private const val KEY_CURRENT_DAILY_TRADES = "current_daily_trades"
        private const val KEY_CURRENT_DAILY_WINS = "current_daily_wins"
        private const val KEY_CURRENT_DAILY_LOSSES_COUNT = "current_daily_losses_count"
        private const val KEY_OFFICIAL_API_URL = "official_api_url"
        private const val KEY_OFFICIAL_API_TOKEN = "official_api_token"
        private const val KEY_ALLOW_ACCESSIBILITY_AUTOMATION = "allow_accessibility_automation"
        private const val KEY_W_EMA = "weight_ema"
        private const val KEY_W_RSI = "weight_rsi"
        private const val KEY_W_CANDLE = "weight_candle"
        private const val KEY_DEMO_SAMPLES = "demo_sample_count"
        private const val KEY_OVERLAY_X = "overlay_x"
        private const val KEY_OVERLAY_Y = "overlay_y"
        private const val KEY_OVERLAY_PINNED = "overlay_pinned"
        private const val KEY_OPERATION_DURATION_SEC = "operation_duration_sec"
        private const val KEY_MIN_CONFIDENCE_PCT = "min_confidence_pct"
        private const val KEY_DAILY_PROFIT_GOAL = "daily_profit_goal"
        private const val KEY_MAX_STOP_LOSS_COUNT = "max_stop_loss_count"
        private const val KEY_CURRENT_DAILY_PROFIT = "current_daily_profit"
        private const val KEY_LOSS_RECOVERY_ENABLED = "loss_recovery_enabled"
        private const val KEY_ACCUMULATED_RECOVERY_LOSS = "accumulated_recovery_loss"
        private const val KEY_TRADE_HISTORY = "persisted_trade_history_json"
        private const val KEY_PREFERRED_BROKER_PKG = "preferred_broker_package"
    }
}
