package com.robizinho.ia.macro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class FuturesForecastItem(
    val asset: String,
    val region: String,
    val direction: String,
    val probabilityPct: Int,
    val horizon: String,
    val driver: String
)

data class WorldNewsItem(
    val region: String,
    val headline: String,
    val impact: String,
    val bias: String,
    val summary: String
)

data class GlobalMarketIntel(
    val updatedAt: String,
    val globalSentiment: String,
    val macroBiasScore: Double,
    val executiveSummary: String,
    val futuresForecasts: List<FuturesForecastItem>,
    val worldNews: List<WorldNewsItem>
)

class GlobalMarketIntelClient(
    private val baseUrl: String = DEFAULT_SERVER_URL
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun fetchLatestIntel(forceRefresh: Boolean = false): Result<GlobalMarketIntel> =
        withContext(Dispatchers.IO) {
            runCatching {
                val cleanBase = baseUrl.trimEnd('/')
                val suffix = if (forceRefresh) "?refresh=1" else ""
                val request = Request.Builder()
                    .url("$cleanBase/api/global-market-intel$suffix")
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    val bodyText = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val errMsg = runCatching {
                            JSONObject(bodyText).optString("error")
                        }.getOrNull().orEmpty()
                        throw IllegalStateException(
                            errMsg.ifBlank { "Erro HTTP ${response.code} ao buscar notícias e futuros globais." }
                        )
                    }

                    val json = JSONObject(bodyText)
                    val forecastsArr = json.optJSONArray("futuresForecasts")
                    val forecasts = buildList {
                        if (forecastsArr != null) {
                            for (i in 0 until forecastsArr.length()) {
                                val obj = forecastsArr.optJSONObject(i) ?: continue
                                add(
                                    FuturesForecastItem(
                                        asset = obj.optString("asset"),
                                        region = obj.optString("region"),
                                        direction = obj.optString("direction", "LATERAL"),
                                        probabilityPct = obj.optInt("probabilityPct", 60),
                                        horizon = obj.optString("horizon"),
                                        driver = obj.optString("driver")
                                    )
                                )
                            }
                        }
                    }

                    val newsArr = json.optJSONArray("worldNews")
                    val news = buildList {
                        if (newsArr != null) {
                            for (i in 0 until newsArr.length()) {
                                val obj = newsArr.optJSONObject(i) ?: continue
                                add(
                                    WorldNewsItem(
                                        region = obj.optString("region"),
                                        headline = obj.optString("headline"),
                                        impact = obj.optString("impact", "MÉDIO"),
                                        bias = obj.optString("bias", "NEUTRO"),
                                        summary = obj.optString("summary")
                                    )
                                )
                            }
                        }
                    }

                    GlobalMarketIntel(
                        updatedAt = json.optString("updatedAt"),
                        globalSentiment = json.optString("globalSentiment", "MISTO"),
                        macroBiasScore = json.optDouble("macroBiasScore", 0.0),
                        executiveSummary = json.optString("executiveSummary"),
                        futuresForecasts = forecasts,
                        worldNews = news
                    )
                }
            }
        }

    companion object {
        const val DEFAULT_SERVER_URL =
            "https://ais-dev-g3ithw5ay4ahsgizkvreqy-506697900256.us-west2.run.app"
    }
}
