package com.robizinho.ia.safety

import com.robizinho.ia.broker.BrokerConnector
import com.robizinho.ia.model.AccountMode
import com.robizinho.ia.model.ExecutionChannel
import com.robizinho.ia.model.OrderConfirmationResult
import com.robizinho.ia.model.OrderRequest
import com.robizinho.ia.model.ScreenRecognitionState
import com.robizinho.ia.model.StrategyDecision
import com.robizinho.ia.model.TradeDirection
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class OrderExecutionGuard(
    private val safetyPrefs: SafetyPreferences,
    private val brokerConnector: BrokerConnector
) {
    private val executionInFlight = AtomicBoolean(false)
    private val processedKeys = ConcurrentHashMap.newKeySet<String>()
    private var lastAttemptEpochMs: Long = 0L

    sealed class GuardResult {
        data class Blocked(val reason: String) : GuardResult()
        data class Executed(val confirmation: OrderConfirmationResult) : GuardResult()
    }

    suspend fun validateAndExecute(
        screen: ScreenRecognitionState,
        decision: StrategyDecision
    ): GuardResult {
        if (safetyPrefs.isEmergencyStopped()) {
            return GuardResult.Blocked("PARAR TUDO ativo. Execuções bloqueadas.")
        }

        if (!safetyPrefs.isAutoExecutionEnabled()) {
            return GuardResult.Blocked("Controle automático desativado.")
        }

        if (decision.direction == TradeDirection.HOLD || !decision.votes.reliabilityOk) {
            return GuardResult.Blocked("Sinal em AGUARDAR ou dados sem confiabilidade.")
        }

        if (decision.votes.isUnstableMarket) {
            return GuardResult.Blocked("Mercado instável (ER=${String.format("%.2f", decision.votes.efficiencyRatio)}). Entrada bloqueada.")
        }

        val minConfPct = safetyPrefs.getMinConfidencePct()
        if (decision.votes.ia2ConfidencePct < minConfPct || decision.direction != decision.votes.ia1Direction) {
            return GuardResult.Blocked("IA 2 Conferência em ${decision.votes.ia2ConfidencePct}% (< $minConfPct% exigido).")
        }

        if (screen !is ScreenRecognitionState.Identified) {
            val reason = (screen as? ScreenRecognitionState.Unidentified)?.reason ?: "Tela não identificada."
            return GuardResult.Blocked("Bloqueio de segurança: $reason")
        }

        if (screen.confidence < 0.85f || screen.assetSymbol.isBlank() || screen.currentPrice <= 0.0) {
            return GuardResult.Blocked("Ativo, preço ou tela não validados com confiança mínima.")
        }

        safetyPrefs.resetDailyCountersIfNewDay()

        val mode = safetyPrefs.getAccountMode()
        if (mode == AccountMode.REAL && !safetyPrefs.isRealAuthorized()) {
            safetyPrefs.forceDemoMode()
            return GuardResult.Blocked("Conta REAL sem autorização explícita. Revertido para DEMO.")
        }

        val currentProfit = safetyPrefs.getCurrentDailyProfit()
        val profitGoal = safetyPrefs.getDailyProfitGoal()
        if (profitGoal > 0.0 && currentProfit >= profitGoal) {
            safetyPrefs.setAutoExecutionEnabled(false)
            return GuardResult.Blocked("Meta diária atingida (R$ ${String.format("%.2f", currentProfit)} / R$ ${String.format("%.2f", profitGoal)}).")
        }

        val currentStopLosses = safetyPrefs.getCurrentDailyLossesCount()
        val maxStopLosses = safetyPrefs.getMaxStopLossCount()
        if (maxStopLosses > 0 && currentStopLosses >= maxStopLosses) {
            safetyPrefs.setAutoExecutionEnabled(false)
            return GuardResult.Blocked("Quantidade máxima de Stop Loss atingida ($currentStopLosses / $maxStopLosses).")
        }

        val currentLoss = safetyPrefs.getCurrentDailyLoss()
        val maxLoss = safetyPrefs.getMaxDailyLoss()
        if (maxLoss > 0.0 && currentLoss >= maxLoss) {
            safetyPrefs.setAutoExecutionEnabled(false)
            return GuardResult.Blocked("Limite de perda diária atingido (R$ $currentLoss / R$ $maxLoss).")
        }

        val stake = safetyPrefs.computeEffectiveStake()
        if (stake <= 0.0) {
            return GuardResult.Blocked("Preencha o valor de Entrada antes de operar.")
        }

        val durationSeconds = safetyPrefs.getOperationDurationSeconds().coerceAtLeast(DEFAULT_DURATION_SECONDS)
        val now = System.currentTimeMillis()
        if (now - lastAttemptEpochMs < durationSeconds * 1000L) {
            return GuardResult.Blocked("Operação de ${durationSeconds / 60}m em andamento (aguardando expiração).")
        }

        if (!executionInFlight.compareAndSet(false, true)) {
            return GuardResult.Blocked("Ordem em processamento. Repetição bloqueada.")
        }

        try {
            val channel = brokerConnector.activeChannel()
            if (channel == ExecutionChannel.NONE) {
                return GuardResult.Blocked("Nenhum canal permitido ativo (configure API Oficial ou Acessibilidade autorizada).")
            }

            // Se for automação visual, exige botões validados na tela
            if (channel.isVisualAutomation) {
                val targetButton = when (decision.direction) {
                    TradeDirection.BUY -> screen.buttons.buyButton
                    TradeDirection.SELL -> screen.buttons.sellButton
                    TradeDirection.HOLD -> null
                }
                if (targetButton == null) {
                    return GuardResult.Blocked("Botão de ${decision.direction.ptLabel} não identificado na tela.")
                }
            }

            val idempotencyKey = "rbz-${screen.assetSymbol}-${decision.direction.name}-${now / 15000}-${UUID.randomUUID().toString().take(6)}"
            if (!processedKeys.add(idempotencyKey)) {
                return GuardResult.Blocked("Chave de idempotência já utilizada.")
            }

            lastAttemptEpochMs = now

            val request = OrderRequest(
                idempotencyKey = idempotencyKey,
                assetSymbol = screen.assetSymbol,
                direction = decision.direction,
                stakeAmount = stake,
                expectedPrice = screen.currentPrice,
                accountMode = mode,
                screenState = screen,
                expirationSeconds = durationSeconds
            )

            // IMPORTANTE: Nunca repetir a ordem em caso de falha ou incerteza de confirmação.
            val confirmation = brokerConnector.placeAndConfirmOrder(request)
            val nowTime = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
            when (confirmation) {
                is OrderConfirmationResult.Confirmed -> {
                    safetyPrefs.recordAcceptedTrade()
                    safetyPrefs.appendTradeHistory(
                        time = nowTime,
                        asset = screen.assetSymbol,
                        direction = decision.direction.ptLabel,
                        status = "ABERTA_1M",
                        detail = "R$ ${String.format("%.2f", stake)} · ${decision.votes.trendMapLabel}"
                    )
                }
                is OrderConfirmationResult.UncertainNoRetry -> {
                    safetyPrefs.setAutoExecutionEnabled(false)
                    safetyPrefs.appendTradeHistory(
                        time = nowTime,
                        asset = screen.assetSymbol,
                        direction = decision.direction.ptLabel,
                        status = "INCERTA",
                        detail = confirmation.reason
                    )
                }
                is OrderConfirmationResult.Rejected -> {
                    safetyPrefs.appendTradeHistory(
                        time = nowTime,
                        asset = screen.assetSymbol,
                        direction = decision.direction.ptLabel,
                        status = "REJEITADA",
                        detail = confirmation.reason
                    )
                }
            }
            return GuardResult.Executed(confirmation)
        } finally {
            executionInFlight.set(false)
        }
    }

    companion object {
        private const val DEFAULT_DURATION_SECONDS = 60
    }
}
