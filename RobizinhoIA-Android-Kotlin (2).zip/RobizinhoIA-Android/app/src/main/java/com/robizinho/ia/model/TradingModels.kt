package com.robizinho.ia.model

import android.graphics.Rect

enum class AccountMode {
    DEMO,
    REAL
}

enum class TradeDirection(val ptLabel: String) {
    BUY("COMPRAR"),
    SELL("VENDER"),
    HOLD("AGUARDAR")
}

enum class ExecutionChannel(val label: String, val isVisualAutomation: Boolean) {
    OFFICIAL_API("API Oficial da Corretora", false),
    AUTHORIZED_ACCESSIBILITY("Automação Visual Autorizada (AccessibilityService)", true),
    NONE("Nenhum canal ativo", false)
}

data class BrokerButtonBounds(
    val buyButton: Rect?,
    val sellButton: Rect?
)

sealed class ScreenRecognitionState {
    data class Identified(
        val packageName: String,
        val brokerName: String,
        val assetSymbol: String,
        val currentPrice: Double,
        val confidence: Float,
        val chartTrendDelta: Double,
        val buttons: BrokerButtonBounds,
        val capturedAtMs: Long = System.currentTimeMillis()
    ) : ScreenRecognitionState()

    data class Unidentified(
        val reason: String,
        val capturedAtMs: Long = System.currentTimeMillis()
    ) : ScreenRecognitionState()
}

data class StrategyVotes(
    val emaCrossoverScore: Double,
    val rsiMomentumScore: Double,
    val candleStructureScore: Double,
    val combinedScore: Double,
    val reliabilityOk: Boolean,
    val explanation: String,
    val ia1Direction: TradeDirection = TradeDirection.HOLD,
    val ia2Direction: TradeDirection = TradeDirection.HOLD,
    val ia4Direction: TradeDirection = TradeDirection.HOLD,
    val ia5Direction: TradeDirection = TradeDirection.HOLD,
    val ia2ConfidencePct: Int = 0,
    val isUnstableMarket: Boolean = false,
    val efficiencyRatio: Double = 1.0,
    val trendMapLabel: String = "LATERAL",
    val ia3Dialogue: String = ""
)

data class StrategyDecision(
    val direction: TradeDirection,
    val confidence: Double,
    val votes: StrategyVotes,
    val timestampMs: Long = System.currentTimeMillis()
)

data class StrategyWeights(
    val emaWeight: Double = 0.40,
    val rsiWeight: Double = 0.30,
    val candleWeight: Double = 0.30,
    val demoSampleCount: Int = 0
)

data class OrderRequest(
    val idempotencyKey: String,
    val assetSymbol: String,
    val direction: TradeDirection,
    val stakeAmount: Double,
    val expectedPrice: Double,
    val accountMode: AccountMode,
    val screenState: ScreenRecognitionState.Identified,
    val expirationSeconds: Int = 60
)

sealed class OrderConfirmationResult {
    data class Confirmed(
        val orderId: String,
        val channel: ExecutionChannel,
        val acceptedPrice: Double,
        val details: String
    ) : OrderConfirmationResult()

    data class Rejected(
        val channel: ExecutionChannel,
        val reason: String
    ) : OrderConfirmationResult()

    data class UncertainNoRetry(
        val channel: ExecutionChannel,
        val reason: String
    ) : OrderConfirmationResult()
}
