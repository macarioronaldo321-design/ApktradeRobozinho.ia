package com.robizinho.ia.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.robizinho.ia.model.BrokerButtonBounds
import com.robizinho.ia.model.ScreenRecognitionState
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

class ScreenCaptureManager(private val context: Context) {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private val latestBitmap = AtomicReference<Bitmap?>(null)
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = DisplayMetrics.DENSITY_HIGH

    fun isCapturing(): Boolean = mediaProjection != null && virtualDisplay != null

    fun startProjection(resultCode: Int, data: Intent): Boolean {
        stopProjection()
        val projectionManager =
            context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, data) ?: return false
        mediaProjection = projection

        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        // Reduz resolução em 50% para manter baixo consumo de memória e latência
        screenWidth = (metrics.widthPixels / 2).coerceAtLeast(540)
        screenHeight = (metrics.heightPixels / 2).coerceAtLeast(960)
        screenDensity = metrics.densityDpi

        captureThread = HandlerThread("RobizinhoCaptureThread").apply { start() }
        captureHandler = Handler(captureThread!!.looper)

        imageReader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2
        ).apply {
            setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * screenWidth

                    val bitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
                    bitmap.recycle()

                    latestBitmap.getAndSet(cropped)?.recycle()
                } catch (_: Throwable) {
                } finally {
                    image.close()
                }
            }, captureHandler)
        }

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopProjection()
            }
        }, captureHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "RobizinhoMediaProjection",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        )
        return true
    }

    suspend fun analyzeCurrentScreen(
        activePackageHint: String?,
        accessibilityButtons: BrokerButtonBounds? = null,
        preferredBrokerPackage: String? = null
    ): ScreenRecognitionState {
        if (!isCapturing()) {
            return ScreenRecognitionState.Unidentified("Captura MediaProjection não iniciada.")
        }

        val normalizedPkg = activePackageHint?.trim().orEmpty()
        if (normalizedPkg.isNotBlank()) {
            if (normalizedPkg.equals(context.packageName, ignoreCase = true)) {
                return ScreenRecognitionState.Unidentified("Abra sua corretora para o Robozinho operar.")
            }
            if (IGNORED_SYSTEM_PACKAGES.any { normalizedPkg.contains(it, ignoreCase = true) }) {
                return ScreenRecognitionState.Unidentified("Aguardando tela de uma corretora...")
            }
            if (!preferredBrokerPackage.isNullOrBlank() &&
                !normalizedPkg.equals(preferredBrokerPackage.trim(), ignoreCase = true) &&
                !isBrowserPackage(normalizedPkg)
            ) {
                return ScreenRecognitionState.Unidentified("Aguardando corretora selecionada...")
            }
        }

        val frame = latestBitmap.get()?.let { src ->
            if (!src.isRecycled) src.copy(Bitmap.Config.ARGB_8888, false) else null
        } ?: return ScreenRecognitionState.Unidentified("Nenhum frame capturado ainda.")

        return try {
            val ocrResult = recognizeText(frame)
            val chartDelta = estimateChartColorDelta(frame)
            val colorButtons = detectGreenRedActionButtons(frame)
            parseBrokerScreen(
                ocr = ocrResult,
                chartDelta = chartDelta,
                activePackageHint = normalizedPkg.ifBlank { null },
                accessibilityButtons = accessibilityButtons,
                colorButtons = colorButtons
            )
        } finally {
            frame.recycle()
        }
    }

    private suspend fun recognizeText(bitmap: Bitmap): Text? =
        suspendCancellableCoroutine { cont ->
            val input = InputImage.fromBitmap(bitmap, 0)
            textRecognizer.process(input)
                .addOnSuccessListener { text ->
                    if (cont.isActive) cont.resume(text)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(null)
                }
        }

    /**
     * Analisa pixels da área central do gráfico para estimar predominância recente de candles verdes vs vermelhos.
     */
    private fun estimateChartColorDelta(bitmap: Bitmap): Double {
        val left = (bitmap.width * 0.45).toInt()
        val right = (bitmap.width * 0.92).toInt()
        val top = (bitmap.height * 0.20).toInt()
        val bottom = (bitmap.height * 0.65).toInt()

        var greenScore = 0
        var redScore = 0
        for (y in top until bottom step 6) {
            for (x in left until right step 6) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                if (g > r + 32 && g > b + 18) greenScore++
                if (r > g + 32 && r > b + 18) redScore++
            }
        }
        val total = (greenScore + redScore).coerceAtLeast(1)
        return ((greenScore - redScore).toDouble() / total).coerceIn(-1.0, 1.0)
    }

    /**
     * Fallback visual universal para corretoras com botões de ícone/seta (verde = compra/alta, vermelho = venda/baixa)
     * na metade inferior ou lateral direita da tela.
     */
    private fun detectGreenRedActionButtons(bitmap: Bitmap): BrokerButtonBounds {
        val startY = (bitmap.height * 0.54).toInt()
        val endY = (bitmap.height * 0.95).toInt()
        val step = 6

        var gCount = 0
        var gMinX = Int.MAX_VALUE
        var gMaxX = Int.MIN_VALUE
        var gMinY = Int.MAX_VALUE
        var gMaxY = Int.MIN_VALUE

        var rCount = 0
        var rMinX = Int.MAX_VALUE
        var rMaxX = Int.MIN_VALUE
        var rMinY = Int.MAX_VALUE
        var rMaxY = Int.MIN_VALUE

        for (y in startY until endY step step) {
            for (x in 0 until bitmap.width step step) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF

                val isButtonGreen = g >= 115 && g > r + 42 && g > b + 28
                val isButtonRed = r >= 135 && r > g + 45 && r > b + 35

                if (isButtonGreen) {
                    gCount++
                    if (x < gMinX) gMinX = x
                    if (x > gMaxX) gMaxX = x
                    if (y < gMinY) gMinY = y
                    if (y > gMaxY) gMaxY = y
                } else if (isButtonRed) {
                    rCount++
                    if (x < rMinX) rMinX = x
                    if (x > rMaxX) rMaxX = x
                    if (y < rMinY) rMinY = y
                    if (y > rMaxY) rMaxY = y
                }
            }
        }

        val greenRect = if (gCount >= 30 && (gMaxX - gMinX) >= 36 && (gMaxY - gMinY) >= 18) {
            Rect(gMinX * 2, gMinY * 2, gMaxX * 2, gMaxY * 2)
        } else null

        val redRect = if (rCount >= 30 && (rMaxX - rMinX) >= 36 && (rMaxY - rMinY) >= 18) {
            Rect(rMinX * 2, rMinY * 2, rMaxX * 2, rMaxY * 2)
        } else null

        if (greenRect != null && redRect != null && Rect.intersects(greenRect, redRect)) {
            return BrokerButtonBounds(null, null)
        }

        return BrokerButtonBounds(buyButton = greenRect, sellButton = redRect)
    }

    private fun parseBrokerScreen(
        ocr: Text?,
        chartDelta: Double,
        activePackageHint: String?,
        accessibilityButtons: BrokerButtonBounds?,
        colorButtons: BrokerButtonBounds
    ): ScreenRecognitionState {
        if (ocr == null || ocr.text.isBlank()) {
            return ScreenRecognitionState.Unidentified("OCR sem leitura textual na tela atual.")
        }

        val fullText = ocr.text

        // Reconhece pares Forex/OTC (EUR/USD, EURUSD OTC), Cripto (BTC/USDT, BTCUSDT), B3 (PETR4, WINQ25) e índices
        val assetRegex = Regex(
            """\b([A-Z]{3,5}[/-][A-Z]{3,5}(?:\s*\(?OTC\)?)?|(?:EUR|GBP|USD|JPY|AUD|CAD|CHF|NZD|BTC|ETH|SOL|XRP|BNB|DOGE){2}(?:\s*\(?OTC\)?)?|[A-Z]{4}[0-9]{1,2}|US30|NAS100|SPX500|XAUUSD)\b"""
        )
        val priceRegex = Regex("""\b([0-9]{1,6}[.,][0-9]{2,5})\b""")

        val assetMatch = assetRegex.find(fullText)?.value?.replace(Regex("""\s+"""), " ")?.trim()
        val allPrices = priceRegex.findAll(fullText)
            .mapNotNull { it.value.replace(",", ".").toDoubleOrNull() }
            .filter { it > 0.0 }
            .toList()
        // Prioriza cotações com mais precisão ou valor realista
        val parsedPrice = allPrices.firstOrNull()

        var ocrBuyRect: Rect? = null
        var ocrSellRect: Rect? = null

        for (block in ocr.textBlocks) {
            for (line in block.lines) {
                val label = line.text.trim().uppercase()
                if (label.length > 24) continue
                val box = line.boundingBox ?: continue
                // Escala de volta para coordenadas reais da tela (captura foi 50%)
                val scaledBox = Rect(box.left * 2, box.top * 2, box.right * 2, box.bottom * 2)
                if (ocrBuyRect == null && BUY_KEYWORDS.any { label == it || label.contains(it) }) {
                    ocrBuyRect = scaledBox
                }
                if (ocrSellRect == null && SELL_KEYWORDS.any { label == it || label.contains(it) }) {
                    ocrSellRect = scaledBox
                }
            }
        }

        val resolvedBuy = accessibilityButtons?.buyButton ?: ocrBuyRect ?: colorButtons.buyButton
        val resolvedSell = accessibilityButtons?.sellButton ?: ocrSellRect ?: colorButtons.sellButton
        val hasButtons = resolvedBuy != null && resolvedSell != null

        val detectedBrokerBrand = detectBrokerName(fullText, activePackageHint)
        val isTradingContext = detectedBrokerBrand != null ||
            (hasButtons && !assetMatch.isNullOrBlank() && parsedPrice != null) ||
            (isBrowserPackage(activePackageHint) && !assetMatch.isNullOrBlank() && parsedPrice != null && hasButtons)

        if (!isTradingContext) {
            return ScreenRecognitionState.Unidentified("Nenhuma corretora detectada na tela atual.")
        }

        if (assetMatch.isNullOrBlank() || parsedPrice == null || parsedPrice <= 0.0) {
            return ScreenRecognitionState.Unidentified("Ativo ou preço não identificado com clareza na tela.")
        }

        val isOneMin = Regex("""\b(1\s*m|M1|1\s*min|60\s*s|01:00)\b""", RegexOption.IGNORE_CASE).containsMatchIn(fullText)
        val baseBrokerName = detectedBrokerBrand ?: "Corretora"
        val brokerLabel = if (isOneMin) "$baseBrokerName · 1m" else baseBrokerName

        val confidence = when {
            accessibilityButtons?.buyButton != null && accessibilityButtons.sellButton != null -> 0.96f
            ocrBuyRect != null && ocrSellRect != null -> 0.94f
            colorButtons.buyButton != null && colorButtons.sellButton != null -> 0.89f
            else -> 0.74f
        }

        return ScreenRecognitionState.Identified(
            packageName = activePackageHint ?: "universal.broker.screen",
            brokerName = brokerLabel,
            assetSymbol = assetMatch,
            currentPrice = parsedPrice,
            confidence = confidence,
            chartTrendDelta = chartDelta,
            buttons = BrokerButtonBounds(buyButton = resolvedBuy, sellButton = resolvedSell)
        )
    }

    private fun detectBrokerName(fullText: String, packageHint: String?): String? {
        val pkg = packageHint.orEmpty().lowercase()
        for ((key, display) in BROKER_CATALOG) {
            if (pkg.contains(key) || fullText.contains(display, ignoreCase = true) || fullText.contains(key, ignoreCase = true)) {
                return display
            }
        }
        return null
    }

    private fun isBrowserPackage(packageHint: String?): Boolean {
        val pkg = packageHint.orEmpty().lowercase()
        return BROWSER_PACKAGES.any { pkg.contains(it) }
    }

    fun stopProjection() {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (_: Throwable) {}
        imageReader = null

        try {
            mediaProjection?.stop()
        } catch (_: Throwable) {}
        mediaProjection = null

        latestBitmap.getAndSet(null)?.recycle()

        try {
            captureThread?.quitSafely()
        } catch (_: Throwable) {}
        captureThread = null
        captureHandler = null
    }

    companion object {
        private val BUY_KEYWORDS = listOf(
            "COMPRAR", "COMPRA", "BUY", "ACIMA", "CALL", "HIGHER", "HIGH", "UP", "SUBIR", "CIMA", "LONG", "ALTA"
        )
        private val SELL_KEYWORDS = listOf(
            "VENDER", "VENDA", "SELL", "ABAIXO", "PUT", "LOWER", "LOW", "DOWN", "DESCER", "BAIXO", "SHORT", "BAIXA"
        )

        private val BROKER_CATALOG = listOf(
            "mercadotrade" to "Mercado Trade",
            "quotex" to "Quotex",
            "pocketoption" to "Pocket Option",
            "iqoption" to "IQ Option",
            "exnova" to "Exnova",
            "binomo" to "Binomo",
            "olymptrade" to "Olymp Trade",
            "olymp" to "Olymp Trade",
            "deriv" to "Deriv",
            "binance" to "Binance",
            "bybit" to "Bybit",
            "okx" to "OKX",
            "tradingview" to "TradingView",
            "bullex" to "Bullex",
            "polarium" to "Polarium",
            "homebroker" to "Home Broker",
            "ebinex" to "Ebinex",
            "spectre" to "Spectre",
            "avalon" to "Avalon",
            "xtrade" to "XTrade"
        )

        private val BROWSER_PACKAGES = listOf(
            "chrome", "sbrowser", "firefox", "emmx", "opera", "brave", "webview", "duckduckgo"
        )

        private val IGNORED_SYSTEM_PACKAGES = listOf(
            "systemui", "launcher", "trebuchet", "nexuslauncher", "miui.home", "sec.android.app.launcher",
            "inputmethod", "gboard", "whatsapp", "instagram", "facebook", "youtube", "android.settings"
        )
    }
}
