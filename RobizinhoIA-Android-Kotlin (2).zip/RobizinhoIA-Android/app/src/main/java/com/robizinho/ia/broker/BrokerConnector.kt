package com.robizinho.ia.broker

import android.graphics.Rect
import com.robizinho.ia.model.ExecutionChannel
import com.robizinho.ia.model.OrderConfirmationResult
import com.robizinho.ia.model.OrderRequest
import com.robizinho.ia.model.TradeDirection
import com.robizinho.ia.safety.SafetyPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

interface BrokerConnector {
    fun activeChannel(): ExecutionChannel
    suspend fun placeAndConfirmOrder(request: OrderRequest): OrderConfirmationResult
}

/**
 * Conector híbrido transparente:
 * 1. Prioriza API Oficial da Corretora quando configurada pelo usuário.
 * 2. Alternativamente, usa AccessibilityService autorizado apenas se explicitamente permitido
 *    pelo usuário e pela corretora — sempre identificado como Automação Visual, nunca como API real.
 */
class HybridBrokerConnector(
    private val safetyPrefs: SafetyPreferences
) : BrokerConnector {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(6, TimeUnit.SECONDS)
        .build()

    override fun activeChannel(): ExecutionChannel {
        val apiUrl = safetyPrefs.getOfficialApiUrl()
        val apiToken = safetyPrefs.getOfficialApiToken()
        if (apiUrl.startsWith("https://") && apiToken.isNotBlank()) {
            return ExecutionChannel.OFFICIAL_API
        }

        if (safetyPrefs.isAccessibilityAutomationAllowedByUser() &&
            RobizinhoAccessibilityService.isRunning()
        ) {
            return ExecutionChannel.AUTHORIZED_ACCESSIBILITY
        }

        return ExecutionChannel.NONE
    }

    override suspend fun placeAndConfirmOrder(request: OrderRequest): OrderConfirmationResult {
        return when (activeChannel()) {
            ExecutionChannel.OFFICIAL_API -> sendViaOfficialApi(request)
            ExecutionChannel.AUTHORIZED_ACCESSIBILITY -> sendViaAccessibilityAutomation(request)
            ExecutionChannel.NONE -> OrderConfirmationResult.Rejected(
                channel = ExecutionChannel.NONE,
                reason = "Nenhum canal de execução configurado ou autorizado."
            )
        }
    }

    private suspend fun sendViaOfficialApi(request: OrderRequest): OrderConfirmationResult =
        withContext(Dispatchers.IO) {
            val baseUrl = safetyPrefs.getOfficialApiUrl().trimEnd('/')
            val token = safetyPrefs.getOfficialApiToken()

            val payload = JSONObject().apply {
                put("idempotency_key", request.idempotencyKey)
                put("asset", request.assetSymbol)
                put("side", request.direction.name)
                put("amount", request.stakeAmount)
                put("account_mode", request.accountMode.name)
                put("expected_price", request.expectedPrice)
                put("duration_seconds", request.expirationSeconds)
                put("timeframe", "${request.expirationSeconds / 60}m")
            }

            val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val httpRequest = Request.Builder()
                .url("$baseUrl/v1/orders")
                .addHeader("Authorization", "Bearer $token")
                .addHeader("X-Idempotency-Key", request.idempotencyKey)
                .post(body)
                .build()

            try {
                httpClient.newCall(httpRequest).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext OrderConfirmationResult.Rejected(
                            channel = ExecutionChannel.OFFICIAL_API,
                            reason = "API rejeitou ordem (HTTP ${response.code})."
                        )
                    }
                    val json = JSONObject(raw)
                    val status = json.optString("status")
                    val orderId = json.optString("order_id")
                    val acceptedPrice = json.optDouble("accepted_price", request.expectedPrice)

                    if (status.equals("ACCEPTED", ignoreCase = true) && orderId.isNotBlank()) {
                        OrderConfirmationResult.Confirmed(
                            orderId = orderId,
                            channel = ExecutionChannel.OFFICIAL_API,
                            acceptedPrice = acceptedPrice,
                            details = "Ordem confirmada pela API oficial ($orderId)."
                        )
                    } else {
                        OrderConfirmationResult.UncertainNoRetry(
                            channel = ExecutionChannel.OFFICIAL_API,
                            reason = "Resposta sem confirmação explícita de aceite. Não repetida por segurança."
                        )
                    }
                }
            } catch (e: Exception) {
                // Regra estrita: falha de rede/timeout após envio NUNCA gera retry automático.
                OrderConfirmationResult.UncertainNoRetry(
                    channel = ExecutionChannel.OFFICIAL_API,
                    reason = "Timeout/erro de rede ao confirmar ordem (${e.message}). Reenvio bloqueado."
                )
            }
        }

    private suspend fun sendViaAccessibilityAutomation(request: OrderRequest): OrderConfirmationResult {
        val service = RobizinhoAccessibilityService.instance()
            ?: return OrderConfirmationResult.Rejected(
                channel = ExecutionChannel.AUTHORIZED_ACCESSIBILITY,
                reason = "AccessibilityService não está ativo no sistema."
            )

        val targetBounds: Rect? = when (request.direction) {
            TradeDirection.BUY -> request.screenState.buttons.buyButton
            TradeDirection.SELL -> request.screenState.buttons.sellButton
            TradeDirection.HOLD -> null
        }

        if (targetBounds == null) {
            return OrderConfirmationResult.Rejected(
                channel = ExecutionChannel.AUTHORIZED_ACCESSIBILITY,
                reason = "Coordenadas do botão ${request.direction.ptLabel} ausentes."
            )
        }

        val clicked = service.performValidatedTradeTap(
            expectedPackage = request.screenState.packageName,
            direction = request.direction,
            fallbackBounds = targetBounds
        )

        if (!clicked) {
            return OrderConfirmationResult.Rejected(
                channel = ExecutionChannel.AUTHORIZED_ACCESSIBILITY,
                reason = "Não foi possível acionar o controle autorizado na janela ativa."
            )
        }

        // Aguarda retorno visual da corretora para verificar aceite (sem nunca repetir o toque)
        delay(700)
        val confirmedInUi = service.verifyOrderAcceptedOnScreen(request.assetSymbol)
        return if (confirmedInUi) {
            OrderConfirmationResult.Confirmed(
                orderId = "UI-${request.idempotencyKey}",
                channel = ExecutionChannel.AUTHORIZED_ACCESSIBILITY,
                acceptedPrice = request.expectedPrice,
                details = "Automação visual confirmou posição aberta na interface."
            )
        } else {
            OrderConfirmationResult.UncertainNoRetry(
                channel = ExecutionChannel.AUTHORIZED_ACCESSIBILITY,
                reason = "Toque executado, mas aceite visual não foi confirmado. Auto-execução pausada sem retry."
            )
        }
    }
}
