package com.robizinho.ia.service

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.robizinho.ia.R
import com.robizinho.ia.broker.HybridBrokerConnector
import com.robizinho.ia.broker.RobizinhoAccessibilityService
import com.robizinho.ia.capture.ScreenCaptureManager
import com.robizinho.ia.model.AccountMode
import com.robizinho.ia.model.OrderConfirmationResult
import com.robizinho.ia.model.ScreenRecognitionState
import com.robizinho.ia.model.TradeDirection
import com.robizinho.ia.safety.OrderExecutionGuard
import com.robizinho.ia.safety.SafetyPreferences
import com.robizinho.ia.strategy.TradingStrategyEngine
import com.robizinho.ia.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class RobizinhoFloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var safetyPrefs: SafetyPreferences
    private lateinit var captureManager: ScreenCaptureManager
    private lateinit var brokerConnector: HybridBrokerConnector
    private lateinit var executionGuard: OrderExecutionGuard
    private val strategyEngine = TradingStrategyEngine()

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var monitorJob: Job? = null

    private var bubbleView: View? = null
    private var panelView: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var isPanelExpanded = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var activeTradeEndsAtMs: Long = 0L

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        safetyPrefs = SafetyPreferences(this)
        captureManager = ScreenCaptureManager(this)
        brokerConnector = HybridBrokerConnector(safetyPrefs)
        executionGuard = OrderExecutionGuard(safetyPrefs, brokerConnector)

        acquireBackgroundWakeLock()
        createNotificationChannel()
        startForegroundCompat(withMediaProjection = false)

        if (Settings.canDrawOverlays(this)) {
            attachOverlayViews()
            startMonitoringLoop()
        } else {
            stopSelf()
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Mantém o serviço flutuante ativo em segundo plano mesmo se o app principal for fechado dos recentes.
        super.onTaskRemoved(rootIntent)
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireBackgroundWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RobozinhoIA::BackgroundMonitor").apply {
            setReferenceCounted(false)
            if (!isHeld) acquire()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ATTACH_PROJECTION -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (resultCode == Activity.RESULT_OK && data != null) {
                    startForegroundCompat(withMediaProjection = true)
                    captureManager.startProjection(resultCode, data)
                }
            }
            ACTION_TOGGLE_AUTO -> {
                if (safetyPrefs.isEmergencyStopped()) {
                    safetyPrefs.setEmergencyStopped(false)
                }
                safetyPrefs.setAutoExecutionEnabled(!safetyPrefs.isAutoExecutionEnabled())
                refreshOverlayStaticLabels()
                updateOngoingNotification()
            }
            ACTION_TOGGLE_PIN -> {
                safetyPrefs.setOverlayPinned(!safetyPrefs.isOverlayPinned())
                refreshOverlayStaticLabels()
                updateOngoingNotification()
            }
            ACTION_EMERGENCY_STOP -> {
                triggerEmergencyStop()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)
    }

    private fun buildOngoingNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val toggleAutoIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, RobizinhoFloatingService::class.java).apply { action = ACTION_TOGGLE_AUTO },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, RobizinhoFloatingService::class.java).apply { action = ACTION_EMERGENCY_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val wins = safetyPrefs.getCurrentDailyWins()
        val losses = safetyPrefs.getCurrentDailyLossesCount()
        val total = wins + losses
        val winRatePct = if (total > 0) (wins * 100) / total else 0
        val modeLabel = safetyPrefs.getAccountMode().name
        val pinLabel = if (safetyPrefs.isOverlayPinned()) " · FIXADO" else ""
        val autoLabel = when {
            safetyPrefs.isEmergencyStopped() -> "PARADO"
            safetyPrefs.isAutoExecutionEnabled() -> "AUTO ON"
            else -> "PAUSADO"
        }

        val toggleLabel = if (safetyPrefs.isAutoExecutionEnabled()) "Pausar" else "Ligar Auto"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Robozinho IA · $modeLabel · $autoLabel$pinLabel")
            .setContentText("W:$wins | L:$losses ($winRatePct%) · Ops ${safetyPrefs.getCurrentDailyTrades()} (Livre)")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(0, toggleLabel, toggleAutoIntent)
            .addAction(0, "PARAR TUDO", stopIntent)
            .build()
    }

    private fun updateOngoingNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildOngoingNotification())
    }

    private fun startForegroundCompat(withMediaProjection: Boolean) {
        val notification = buildOngoingNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (withMediaProjection) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun attachOverlayViews() {
        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.overlay_bubble, null)
        panelView = inflater.inflate(R.layout.overlay_panel, null)

        val savedX = safetyPrefs.getOverlayX()
        val savedY = safetyPrefs.getOverlayY()

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        setupBubbleDragAndTap(bubbleView!!)
        setupPanelControls(panelView!!)

        windowManager.addView(bubbleView, bubbleParams)
    }

    private fun clampX(x: Int, viewWidth: Int): Int {
        val maxX = (resources.displayMetrics.widthPixels - viewWidth).coerceAtLeast(0)
        return x.coerceIn(0, maxX)
    }

    private fun clampY(y: Int, viewHeight: Int): Int {
        val maxY = (resources.displayMetrics.heightPixels - viewHeight).coerceAtLeast(0)
        return y.coerceIn(48, maxY)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupBubbleDragAndTap(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!safetyPrefs.isOverlayPinned()) {
                        bubbleParams.x = clampX(initialX + (event.rawX - initialTouchX).toInt(), view.width.coerceAtLeast(120))
                        bubbleParams.y = clampY(initialY + (event.rawY - initialTouchY).toInt(), view.height.coerceAtLeast(120))
                        windowManager.updateViewLayout(view, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = abs(event.rawX - initialTouchX)
                    val dy = abs(event.rawY - initialTouchY)
                    if (!safetyPrefs.isOverlayPinned()) {
                        safetyPrefs.saveOverlayPosition(bubbleParams.x, bubbleParams.y)
                    }
                    if (dx < 12 && dy < 12) {
                        togglePanel(expand = true)
                    }
                    true
                }
                else -> false
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupPanelControls(panel: View) {
        val dragListener = View.OnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    panel.tag = intArrayOf(
                        panelParams.x,
                        panelParams.y,
                        event.rawX.toInt(),
                        event.rawY.toInt()
                    )
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!safetyPrefs.isOverlayPinned()) {
                        val start = panel.tag as? IntArray ?: return@OnTouchListener false
                        panelParams.x = clampX(start[0] + (event.rawX.toInt() - start[2]), panel.width.coerceAtLeast(420))
                        panelParams.y = clampY(start[1] + (event.rawY.toInt() - start[3]), panel.height.coerceAtLeast(280))
                        bubbleParams.x = panelParams.x
                        bubbleParams.y = panelParams.y
                        windowManager.updateViewLayout(panel, panelParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!safetyPrefs.isOverlayPinned()) {
                        safetyPrefs.saveOverlayPosition(panelParams.x, panelParams.y)
                    }
                    true
                }
                else -> false
            }
        }

        panel.findViewById<View>(R.id.panelDragHeader).setOnTouchListener(dragListener)
        panel.setOnTouchListener(dragListener)

        panel.findViewById<Button>(R.id.btnPinOverlay).setOnClickListener {
            val nextPinned = !safetyPrefs.isOverlayPinned()
            safetyPrefs.setOverlayPinned(nextPinned)
            safetyPrefs.saveOverlayPosition(panelParams.x, panelParams.y)
            refreshOverlayStaticLabels()
            updateOngoingNotification()
        }

        panel.findViewById<Button>(R.id.btnMinimizeOverlay).setOnClickListener {
            togglePanel(expand = false)
        }

        panel.findViewById<Button>(R.id.btnToggleAuto).setOnClickListener {
            if (safetyPrefs.isEmergencyStopped()) {
                safetyPrefs.setEmergencyStopped(false)
            }
            val next = !safetyPrefs.isAutoExecutionEnabled()
            safetyPrefs.setAutoExecutionEnabled(next)
            refreshOverlayStaticLabels()
            updateOngoingNotification()
        }

        panel.findViewById<Button>(R.id.btnStopAll).setOnClickListener {
            triggerEmergencyStop()
        }

        refreshOverlayStaticLabels()
    }

    private fun togglePanel(expand: Boolean) {
        if (expand == isPanelExpanded) return
        isPanelExpanded = expand
        if (expand) {
            if (bubbleView?.isAttachedToWindow == true) windowManager.removeView(bubbleView)
            if (panelView?.isAttachedToWindow == false) {
                panelParams.x = bubbleParams.x
                panelParams.y = bubbleParams.y
                windowManager.addView(panelView, panelParams)
                refreshOverlayStaticLabels()
            }
        } else {
            if (panelView?.isAttachedToWindow == true) windowManager.removeView(panelView)
            if (bubbleView?.isAttachedToWindow == false) {
                windowManager.addView(bubbleView, bubbleParams)
            }
        }
    }

    private fun triggerEmergencyStop() {
        safetyPrefs.setEmergencyStopped(true)
        safetyPrefs.setAutoExecutionEnabled(false)
        refreshOverlayStaticLabels()
        updateOngoingNotification()
        bubbleView?.findViewById<TextView>(R.id.tvBubbleBadge)?.apply {
            text = "X"
            setTextColor(getColor(R.color.danger_red))
        }
        panelView?.findViewById<TextView>(R.id.tvOverlayLastExecution)?.text =
            "PARAR TUDO ativo"
    }

    private fun refreshOverlayStaticLabels() {
        val panel = panelView ?: return
        val mode = safetyPrefs.getAccountMode()
        val modeView = panel.findViewById<TextView>(R.id.tvModeIndicator)
        modeView.text = mode.name
        modeView.setTextColor(
            getColor(if (mode == AccountMode.DEMO) R.color.accent_emerald else R.color.warn_amber)
        )

        val btnPin = panel.findViewById<Button>(R.id.btnPinOverlay)
        val isPinned = safetyPrefs.isOverlayPinned()
        btnPin.text = if (isPinned) "Fixado" else "Fixar"
        btnPin.setTextColor(
            getColor(if (isPinned) R.color.accent_emerald else R.color.text_secondary)
        )

        val btnAuto = panel.findViewById<Button>(R.id.btnToggleAuto)
        btnAuto.text = when {
            safetyPrefs.isEmergencyStopped() -> "Reativar"
            safetyPrefs.isAutoExecutionEnabled() -> "Pausar"
            else -> "Auto"
        }

        panel.findViewById<TextView>(R.id.tvOverlayRiskCounters).text =
            "${safetyPrefs.getCurrentDailyTrades()} ops (Livre) · " +
                "R$ ${String.format("%.2f", safetyPrefs.getCurrentDailyLoss())}"

        val wins = safetyPrefs.getCurrentDailyWins()
        val losses = safetyPrefs.getCurrentDailyLossesCount()
        val total = wins + losses
        val winRatePct = if (total > 0) (wins * 100) / total else 0
        val nowStr = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
        panel.findViewById<TextView>(R.id.tvOverlayWinLoss).text =
            "W: $wins | L: $losses ($winRatePct%) · $nowStr"
    }

    private fun startMonitoringLoop() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            var tickCounter = 0
            while (isActive) {
                val screenInteractive = powerManager.isInteractive
                val hasOfficialApi = safetyPrefs.getOfficialApiUrl().isNotBlank()
                val a11yService = RobizinhoAccessibilityService.instance()
                val activePkg = a11yService?.currentForegroundPackage
                val a11yButtons = a11yService?.findTradeButtonsInActiveWindow(activePkg)
                val preferredPkg = safetyPrefs.getPreferredBrokerPackage().ifBlank { null }
                val screenState = if (screenInteractive) {
                    withContext(Dispatchers.Default) {
                        captureManager.analyzeCurrentScreen(
                            activePackageHint = activePkg,
                            accessibilityButtons = a11yButtons,
                            preferredBrokerPackage = preferredPkg
                        )
                    }
                } else {
                    ScreenRecognitionState.Unidentified(
                        if (hasOfficialApi) "Tela apagada · operando via API oficial"
                        else "Tela apagada · aguardando tela ou API"
                    )
                }

                val decision = strategyEngine.evaluate(
                    screen = screenState,
                    weights = safetyPrefs.getStrategyWeights(),
                    minConfidencePct = safetyPrefs.getMinConfidencePct()
                )

                updateOverlayTelemetry(screenState, decision)

                if (safetyPrefs.isAutoExecutionEnabled() &&
                    !safetyPrefs.isEmergencyStopped() &&
                    decision.direction != TradeDirection.HOLD &&
                    System.currentTimeMillis() >= activeTradeEndsAtMs
                ) {
                    val result = executionGuard.validateAndExecute(screenState, decision)
                    val statusText = when (result) {
                        is OrderExecutionGuard.GuardResult.Blocked -> "Bloqueado: ${result.reason}"
                        is OrderExecutionGuard.GuardResult.Executed -> when (val conf = result.confirmation) {
                            is OrderConfirmationResult.Confirmed -> {
                                activeTradeEndsAtMs = System.currentTimeMillis() +
                                    safetyPrefs.getOperationDurationSeconds() * 1000L
                                "1m Aberta (${conf.channel.label}): ${conf.orderId}"
                            }
                            is OrderConfirmationResult.Rejected ->
                                "Rejeitada (${conf.channel.label}): ${conf.reason}"
                            is OrderConfirmationResult.UncertainNoRetry ->
                                "Incerto (sem retry): ${conf.reason}"
                        }
                    }
                    panelView?.findViewById<TextView>(R.id.tvOverlayLastExecution)?.text = statusText
                }

                refreshOverlayStaticLabels()
                if (tickCounter % 8 == 0) {
                    updateOngoingNotification()
                }
                tickCounter++
                delay(350)
            }
        }
    }

    private fun updateOverlayTelemetry(
        screen: ScreenRecognitionState,
        decision: com.robizinho.ia.model.StrategyDecision
    ) {
        val direction = decision.direction
        val ia2Pct = decision.votes.ia2ConfidencePct
        val isUnstable = decision.votes.isUnstableMarket
        val remainingSec = ((activeTradeEndsAtMs - System.currentTimeMillis()) / 1000L)
            .coerceAtLeast(0L)

        // Atualiza também a bolha pequena (44dp) para leitura rápida sem expandir o painel
        bubbleView?.findViewById<TextView>(R.id.tvBubbleBadge)?.let { badge ->
            if (safetyPrefs.isEmergencyStopped()) {
                badge.text = "X"
                badge.setTextColor(getColor(R.color.danger_red))
            } else if (remainingSec > 0L) {
                badge.text = "${remainingSec}s"
                badge.setTextColor(getColor(R.color.accent_emerald))
            } else if (isUnstable) {
                badge.text = "~"
                badge.setTextColor(getColor(R.color.warn_amber))
            } else {
                badge.text = when (direction) {
                    TradeDirection.BUY -> "C"
                    TradeDirection.SELL -> "V"
                    TradeDirection.HOLD -> if (ia2Pct > 0) "$ia2Pct" else "IA"
                }
                badge.setTextColor(
                    getColor(
                        when (direction) {
                            TradeDirection.BUY -> R.color.accent_emerald
                            TradeDirection.SELL -> R.color.danger_red
                            TradeDirection.HOLD -> R.color.text_primary
                        }
                    )
                )
            }
        }

        val panel = panelView ?: return
        val tvScreen = panel.findViewById<TextView>(R.id.tvOverlayScreenStatus)
        val tvAsset = panel.findViewById<TextView>(R.id.tvOverlayAssetPrice)
        val tvDecision = panel.findViewById<TextView>(R.id.tvOverlayDecision)

        when (screen) {
            is ScreenRecognitionState.Identified -> {
                tvScreen.text = if (isUnstable) {
                    "${screen.brokerName} · INSTÁVEL"
                } else {
                    "${screen.brokerName} · 5 IAs:$ia2Pct%"
                }
                tvAsset.text = "${screen.assetSymbol} · ${String.format("%.4f", screen.currentPrice)}"
            }
            is ScreenRecognitionState.Unidentified -> {
                tvScreen.text = screen.reason
                tvAsset.text = "-- · --"
            }
        }

        tvDecision.text = when {
            remainingSec > 0L -> "1m · ${remainingSec}s"
            isUnstable -> "INSTÁVEL ($ia2Pct%)"
            direction != TradeDirection.HOLD -> "${direction.ptLabel} ($ia2Pct%)"
            else -> "AGUARDAR ($ia2Pct%)"
        }
        val colorRes = when {
            remainingSec > 0L -> R.color.accent_emerald
            isUnstable -> R.color.warn_amber
            direction == TradeDirection.BUY -> R.color.accent_emerald
            direction == TradeDirection.SELL -> R.color.danger_red
            else -> R.color.warn_amber
        }
        tvDecision.setTextColor(getColor(colorRes))
    }

    override fun onDestroy() {
        super.onDestroy()
        monitorJob?.cancel()
        serviceScope.cancel()
        captureManager.stopProjection()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Throwable) {}
        if (bubbleView?.isAttachedToWindow == true) windowManager.removeView(bubbleView)
        if (panelView?.isAttachedToWindow == true) windowManager.removeView(panelView)
    }

    companion object {
        const val CHANNEL_ID = "robizinho_floating_channel"
        const val NOTIFICATION_ID = 4102
        const val ACTION_ATTACH_PROJECTION = "com.robizinho.ia.ACTION_ATTACH_PROJECTION"
        const val ACTION_TOGGLE_AUTO = "com.robizinho.ia.ACTION_TOGGLE_AUTO"
        const val ACTION_TOGGLE_PIN = "com.robizinho.ia.ACTION_TOGGLE_PIN"
        const val ACTION_EMERGENCY_STOP = "com.robizinho.ia.ACTION_EMERGENCY_STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
