package com.robizinho.ia.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.robizinho.ia.R
import com.robizinho.ia.broker.RobizinhoAccessibilityService
import com.robizinho.ia.model.AccountMode
import com.robizinho.ia.safety.SafetyPreferences
import com.robizinho.ia.service.RobizinhoFloatingService

class MainActivity : AppCompatActivity() {

    private lateinit var safetyPrefs: SafetyPreferences

    private lateinit var tvPermissionStatus: TextView
    private lateinit var tvAccountModeStatus: TextView
    private lateinit var tvActivityLog: TextView
    private lateinit var etStakeAmount: EditText
    private lateinit var etMaxDailyLoss: EditText
    private lateinit var etPreferredBrokerPackage: EditText
    private lateinit var etDailyProfitGoal: EditText
    private lateinit var etMaxStopLossCount: EditText
    private lateinit var cbLossRecovery: CheckBox
    private lateinit var etOfficialApiUrl: EditText

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            appendLog(if (granted) "Permissão de notificação concedida." else "Notificação negada.")
            refreshStatus()
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshStatus()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, RobizinhoFloatingService::class.java).apply {
                    action = RobizinhoFloatingService.ACTION_ATTACH_PROJECTION
                    putExtra(RobizinhoFloatingService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(RobizinhoFloatingService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
                appendLog("MediaProjection autorizada e vinculada ao Foreground Service.")
            } else {
                appendLog("Captura MediaProjection recusada pelo usuário.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        safetyPrefs = SafetyPreferences(this)
        // Regra de segurança obrigatória: sempre iniciar sessão em DEMO
        safetyPrefs.forceDemoMode()

        bindViews()
        bindHandlers()
        requestNotificationIfNeeded()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun bindViews() {
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus)
        tvAccountModeStatus = findViewById(R.id.tvAccountModeStatus)
        tvActivityLog = findViewById(R.id.tvActivityLog)
        etStakeAmount = findViewById(R.id.etStakeAmount)
        etMaxDailyLoss = findViewById(R.id.etMaxDailyLoss)
        etPreferredBrokerPackage = findViewById(R.id.etPreferredBrokerPackage)
        etDailyProfitGoal = findViewById(R.id.etDailyProfitGoal)
        etMaxStopLossCount = findViewById(R.id.etMaxStopLossCount)
        cbLossRecovery = findViewById(R.id.cbLossRecovery)
        etOfficialApiUrl = findViewById(R.id.etOfficialApiUrl)

        val savedStake = safetyPrefs.getStakeAmount()
        val savedLoss = safetyPrefs.getMaxDailyLoss()
        val savedGoal = safetyPrefs.getDailyProfitGoal()
        val savedStopCount = safetyPrefs.getMaxStopLossCount()

        etStakeAmount.setText(if (savedStake > 0.0) formatCleanNumber(savedStake) else "")
        etMaxDailyLoss.setText(if (savedLoss > 0.0) formatCleanNumber(savedLoss) else "")
        etPreferredBrokerPackage.setText(safetyPrefs.getPreferredBrokerPackage())
        etDailyProfitGoal.setText(if (savedGoal > 0.0) formatCleanNumber(savedGoal) else "")
        etMaxStopLossCount.setText(if (savedStopCount > 0) savedStopCount.toString() else "")
        cbLossRecovery.isChecked = safetyPrefs.isLossRecoveryEnabled()
        etOfficialApiUrl.setText(safetyPrefs.getOfficialApiUrl())

        val savedLines = safetyPrefs.getTradeHistoryLines(limit = 15)
        if (savedLines.isNotEmpty()) {
            tvActivityLog.text = savedLines.joinToString("\n")
        }
    }

    private fun bindHandlers() {
        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            } else {
                appendLog("SYSTEM_ALERT_WINDOW já está autorizada.")
            }
        }

        findViewById<Button>(R.id.btnGrantProjection).setOnClickListener {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mgr.createScreenCaptureIntent())
        }

        findViewById<Button>(R.id.btnOpenAccessibility).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Automação Visual Autorizada")
                .setMessage(
                    "Use o AccessibilityService somente se a corretora permitir automação assistida " +
                        "e você optar explicitamente por esse modo. Esta camada funciona sobre qualquer corretora " +
                        "e não substitui uma API oficial."
                )
                .setPositiveButton("Autorizar e Abrir Configurações") { _, _ ->
                    safetyPrefs.setAccessibilityAutomationAllowedByUser(true)
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        findViewById<Button>(R.id.btnSaveSafetyConfig).setOnClickListener {
            saveInputsFromForm(showFeedback = true)
            refreshStatus()
        }

        findViewById<Button>(R.id.btnAuthorizeRealMode).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Autorizar Operação em Conta REAL")
                .setMessage(
                    "O Robizinho inicia sempre em DEMO. Deseja autorizar explicitamente a execução " +
                        "em conta REAL respeitando a meta de lucro e stop loss configurados?"
                )
                .setPositiveButton("Autorizar REAL") { _, _ ->
                    safetyPrefs.authorizeRealMode(userAcceptedRisk = true)
                    appendLog("Modo REAL autorizado explicitamente pelo usuário.")
                    refreshStatus()
                }
                .setNegativeButton("Manter DEMO") { _, _ ->
                    safetyPrefs.forceDemoMode()
                    refreshStatus()
                }
                .show()
        }

        findViewById<Button>(R.id.btnGrantBatteryExemption).setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                appendLog("Segundo plano sem restrições de bateria já está ativo.")
            }
        }

        findViewById<Button>(R.id.btnStartFloatingService).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                appendLog("Autorize SYSTEM_ALERT_WINDOW antes de iniciar o assistente flutuante.")
                return@setOnClickListener
            }
            if (!saveInputsFromForm(showFeedback = false)) {
                appendLog("Preencha o valor da Entrada (ex: 1 ou 15) antes de iniciar.")
                return@setOnClickListener
            }
            safetyPrefs.setEmergencyStopped(false)
            ContextCompat.startForegroundService(
                this,
                Intent(this, RobizinhoFloatingService::class.java)
            )
            appendLog("Bolha flutuante iniciada para TODAS as corretoras.")
            moveTaskToBack(true)
        }

        findViewById<Button>(R.id.btnOpenBroker).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                appendLog("Autorize SYSTEM_ALERT_WINDOW para a bolha aparecer sobre a corretora.")
                return@setOnClickListener
            }
            if (!saveInputsFromForm(showFeedback = false)) {
                appendLog("Preencha o valor da Entrada (ex: 1 ou 15) antes de abrir a corretora.")
                return@setOnClickListener
            }
            safetyPrefs.setEmergencyStopped(false)
            ContextCompat.startForegroundService(
                this,
                Intent(this, RobizinhoFloatingService::class.java)
            )

            val preferredPkg = etPreferredBrokerPackage.text.toString().trim()
            if (preferredPkg.isNotBlank()) {
                val customIntent = packageManager.getLaunchIntentForPackage(preferredPkg)
                if (customIntent != null) {
                    customIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(customIntent)
                    appendLog("Corretora $preferredPkg aberta com bolha flutuante ativa.")
                    return@setOnClickListener
                }
            }

            showUniversalBrokerPicker()
        }

        findViewById<Button>(R.id.btnEmergencyStopMain).setOnClickListener {
            safetyPrefs.setEmergencyStopped(true)
            safetyPrefs.setAutoExecutionEnabled(false)
            val stopIntent = Intent(this, RobizinhoFloatingService::class.java).apply {
                action = RobizinhoFloatingService.ACTION_EMERGENCY_STOP
            }
            startService(stopIntent)
            appendLog("PARAR TUDO acionado. Execução automática bloqueada.")
            refreshStatus()
        }
    }

    private fun showUniversalBrokerPicker() {
        val detectedBrokers = COMMON_BROKERS.mapNotNull { (label, pkg) ->
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) label to launch else null
        }

        val options = mutableListOf<String>()
        options.add("Qualquer Corretora / Navegador (Modo Universal)")
        detectedBrokers.forEach { options.add("Abrir ${it.first}") }

        AlertDialog.Builder(this)
            .setTitle("Selecionar Corretora")
            .setItems(options.toTypedArray()) { _, which ->
                if (which == 0) {
                    appendLog("Bolha flutuante pronta! Abra qualquer corretora (app ou navegador) e toque em Fixar.")
                    moveTaskToBack(true)
                } else {
                    val selected = detectedBrokers[which - 1]
                    selected.second.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(selected.second)
                    appendLog("${selected.first} aberta. Arraste a bolha e toque em Fixar para operar.")
                }
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun refreshStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessibilityOk = RobizinhoAccessibilityService.isRunning()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)
        tvPermissionStatus.text =
            "Sobreposição: ${if (overlayOk) "OK" else "Pendente"} · " +
                "2º Plano: ${if (batteryOk) "Sem restrição" else "Restrito"} · " +
                "Acessibilidade: ${if (accessibilityOk) "Ativa" else "Inativa"}"

        val mode = safetyPrefs.getAccountMode()
        tvAccountModeStatus.text = if (mode == AccountMode.DEMO) {
            "Modo ativo: DEMO (padrão seguro) · Compatível com TODAS corretoras"
        } else {
            "Modo ativo: REAL (autorizado) · Compatível com TODAS corretoras"
        }
    }

    private fun saveInputsFromForm(showFeedback: Boolean): Boolean {
        val stake = etStakeAmount.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
        if (stake <= 0.0) {
            if (showFeedback) {
                appendLog("Preencha o valor da Entrada (ex: 1 ou 15).")
            }
            return false
        }
        val maxLoss = (etMaxDailyLoss.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
        val profitGoal = (etDailyProfitGoal.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
        val maxStopLosses = (etMaxStopLossCount.text.toString().toIntOrNull() ?: 0).coerceAtLeast(0)
        val recovery = cbLossRecovery.isChecked
        val apiUrl = etOfficialApiUrl.text.toString()
        val preferredPkg = etPreferredBrokerPackage.text.toString().trim()
        safetyPrefs.setPreferredBrokerPackage(preferredPkg)
        safetyPrefs.saveLimits(stake, maxLoss, 99999, apiUrl, profitGoal, maxStopLosses, recovery)
        if (showFeedback) {
            val scopeLabel = if (preferredPkg.isBlank()) "TODAS corretoras" else preferredPkg
            val goalLabel = if (profitGoal > 0.0) "R$$profitGoal" else "Livre"
            val stopLabel = if (maxStopLosses > 0) "$maxStopLosses" else "Livre"
            appendLog("Salvo ($scopeLabel): Entrada=R$$stake, Meta=$goalLabel, StopLoss=$stopLabel.")
        }
        return true
    }

    private fun formatCleanNumber(v: Double): String {
        return if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()
    }

    private fun appendLog(message: String) {
        val prev = tvActivityLog.text.toString()
        tvActivityLog.text = "$message\n$prev".take(1200)
    }

    companion object {
        private val COMMON_BROKERS = listOf(
            "Mercado Trade" to "com.mercadotrade.app",
            "Quotex" to "io.quotex.app",
            "Quotex Web/App" to "com.quotex.app",
            "Pocket Option" to "com.pocketoption.app",
            "IQ Option" to "com.iqoption",
            "Exnova" to "com.exnova.app",
            "Binomo" to "com.binomo.app",
            "Olymp Trade" to "com.olymptrade.app",
            "Deriv" to "com.deriv.app",
            "Binance" to "com.binance.dev",
            "Bybit" to "com.bybit.app",
            "OKX" to "com.okinc.okex.gp",
            "TradingView" to "com.tradingview.tradingviewapp",
            "Bullex" to "com.bullex.app",
            "Home Broker" to "com.homebroker.app",
            "Ebinex" to "com.ebinex.app"
        )
    }
}
