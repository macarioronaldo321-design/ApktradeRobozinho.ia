package com.robizinho.ia.broker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.robizinho.ia.model.BrokerButtonBounds
import com.robizinho.ia.model.TradeDirection
import java.lang.ref.WeakReference

class RobizinhoAccessibilityService : AccessibilityService() {

    @Volatile
    var currentForegroundPackage: String? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceRef = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (!pkg.isNullOrBlank()) {
            currentForegroundPackage = pkg
        }
    }

    override fun onInterrupt() {
        // Sem estado pendente mantido
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceRef = null
    }

    /**
     * Inspeciona a árvore de acessibilidade da corretora ativa (nativa ou WebView/Chrome)
     * para localizar botões de Compra/Alta e Venda/Baixa com coordenadas reais.
     */
    fun findTradeButtonsInActiveWindow(expectedPackage: String? = null): BrokerButtonBounds? {
        val root = rootInActiveWindow ?: return null
        val activePkg = root.packageName?.toString().orEmpty()
        if (activePkg.equals(packageName, ignoreCase = true)) return null
        if (!expectedPackage.isNullOrBlank() &&
            expectedPackage != "universal.broker.screen" &&
            !activePkg.equals(expectedPackage, ignoreCase = true)
        ) {
            return null
        }

        val buyNode = findClickableNodeByKeywords(root, BUY_KEYWORDS, BUY_VIEW_HINTS)
        val sellNode = findClickableNodeByKeywords(root, SELL_KEYWORDS, SELL_VIEW_HINTS)

        val buyRect = buyNode?.let { node ->
            Rect().also { node.getBoundsInScreen(it) }.takeIf { !it.isEmpty }
        }
        val sellRect = sellNode?.let { node ->
            Rect().also { node.getBoundsInScreen(it) }.takeIf { !it.isEmpty }
        }

        return if (buyRect != null || sellRect != null) {
            BrokerButtonBounds(buyButton = buyRect, sellButton = sellRect)
        } else {
            null
        }
    }

    /**
     * Tenta primeiro localizar o nó AccessibilityNodeInfo pelo texto/id do controle em qualquer corretora.
     * Caso a corretora renderize botões em Canvas/WebGL sem nós expostos, usa gesto único
     * no centro das coordenadas validadas pela leitura de tela (OCR ou cor).
     */
    fun performValidatedTradeTap(
        expectedPackage: String,
        direction: TradeDirection,
        fallbackBounds: Rect
    ): Boolean {
        val root = rootInActiveWindow ?: return false
        val activePkg = root.packageName?.toString().orEmpty()
        if (activePkg.equals(packageName, ignoreCase = true)) {
            return false
        }
        if (expectedPackage.isNotBlank() &&
            expectedPackage != "universal.broker.screen" &&
            activePkg.isNotBlank() &&
            !activePkg.equals(expectedPackage, ignoreCase = true)
        ) {
            return false
        }

        val (keywords, hints) = when (direction) {
            TradeDirection.BUY -> BUY_KEYWORDS to BUY_VIEW_HINTS
            TradeDirection.SELL -> SELL_KEYWORDS to SELL_VIEW_HINTS
            TradeDirection.HOLD -> return false
        }

        val matchingNode = findClickableNodeByKeywords(root, keywords, hints)
        if (matchingNode != null && matchingNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true
        }

        val centerX = fallbackBounds.exactCenterX()
        val centerY = fallbackBounds.exactCenterY()
        if (centerX <= 0f || centerY <= 0f) return false

        val path = Path().apply { moveTo(centerX, centerY) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun verifyOrderAcceptedOnScreen(assetSymbol: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val markers = listOf(
            "ordem aberta", "operação ativa", "confirmada", "posição",
            "order opened", "trade opened", "open trades", "active",
            "em aberto", "negociação", "investimento", "investments",
            "tempo restante", assetSymbol
        )
        return containsAnyText(root, markers)
    }

    private fun findClickableNodeByKeywords(
        node: AccessibilityNodeInfo?,
        keywords: List<String>,
        viewIdHints: List<String>
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        val text = ((node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")).trim()
        val viewId = node.viewIdResourceName?.lowercase().orEmpty()

        val textMatched = text.length <= 32 && keywords.any { kw ->
            text.equals(kw, ignoreCase = true) || text.contains(kw, ignoreCase = true)
        }
        val idMatched = viewId.isNotBlank() && viewIdHints.any { viewId.contains(it) }

        if (textMatched || idMatched) {
            var clickableTarget: AccessibilityNodeInfo? = node
            var depth = 0
            while (clickableTarget != null && !clickableTarget.isClickable && depth < 3) {
                clickableTarget = clickableTarget.parent
                depth++
            }
            if (clickableTarget != null && clickableTarget.isClickable) {
                return clickableTarget
            }
        }

        for (i in 0 until node.childCount) {
            val found = findClickableNodeByKeywords(node.getChild(i), keywords, viewIdHints)
            if (found != null) return found
        }
        return null
    }

    private fun containsAnyText(node: AccessibilityNodeInfo?, markers: List<String>): Boolean {
        if (node == null) return false
        val text = (node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")
        if (markers.any { text.contains(it, ignoreCase = true) }) {
            return true
        }
        for (i in 0 until node.childCount) {
            if (containsAnyText(node.getChild(i), markers)) return true
        }
        return false
    }

    companion object {
        private val BUY_KEYWORDS = listOf(
            "COMPRAR", "COMPRA", "BUY", "ACIMA", "CALL", "HIGHER", "HIGH", "UP", "SUBIR", "CIMA", "LONG", "ALTA"
        )
        private val SELL_KEYWORDS = listOf(
            "VENDER", "VENDA", "SELL", "ABAIXO", "PUT", "LOWER", "LOW", "DOWN", "DESCER", "BAIXO", "SHORT", "BAIXA"
        )
        private val BUY_VIEW_HINTS = listOf("call", "buy", "higher", "btn_up", "up_button", "comprar", "acima")
        private val SELL_VIEW_HINTS = listOf("put", "sell", "lower", "btn_down", "down_button", "vender", "abaixo")

        @Volatile
        private var serviceRef: WeakReference<RobizinhoAccessibilityService>? = null

        fun instance(): RobizinhoAccessibilityService? = serviceRef?.get()

        fun isRunning(): Boolean = instance() != null
    }
}
