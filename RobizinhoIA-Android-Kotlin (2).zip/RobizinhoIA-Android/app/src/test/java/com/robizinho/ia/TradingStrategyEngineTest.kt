package com.robizinho.ia

import com.robizinho.ia.model.ScreenRecognitionState
import com.robizinho.ia.model.StrategyWeights
import com.robizinho.ia.model.TradeDirection
import com.robizinho.ia.strategy.TradingStrategyEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class TradingStrategyEngineTest {

    @Test
    fun returnsHoldWhenScreenIsUnidentified() {
        val engine = TradingStrategyEngine()
        val decision = engine.evaluate(
            screen = ScreenRecognitionState.Unidentified("Tela não identificada"),
            weights = StrategyWeights()
        )
        assertEquals(TradeDirection.HOLD, decision.direction)
        assertFalse(decision.votes.reliabilityOk)
    }

    @Test
    fun returnsBuyWhenDualIaConfirmsWithoutPercentageBlock() {
        val engine = TradingStrategyEngine()
        var price = 1.0800
        var lastDecision = com.robizinho.ia.model.StrategyDecision(
            direction = TradeDirection.HOLD,
            confidence = 0.0,
            votes = com.robizinho.ia.model.StrategyVotes(0.0, 0.0, 0.0, 0.0, false, "")
        )
        // Série rápida de M1 com pequenas correções para manter RSI 9 na zona segura (51..70)
        val deltas = listOf(
            0.0005, -0.0003, 0.0004, -0.0002, 0.0005, -0.0002,
            0.0004, -0.0002, 0.0005, 0.0005, 0.0006, 0.0006
        )
        for (delta in deltas) {
            price += delta
            val identified = ScreenRecognitionState.Identified(
                packageName = "com.mercadotrade.app",
                brokerName = "Mercado Trade",
                assetSymbol = "EUR/USD",
                currentPrice = price,
                confidence = 0.95f,
                chartTrendDelta = 0.45,
                buttons = com.robizinho.ia.model.BrokerButtonBounds(null, null)
            )
            lastDecision = engine.evaluate(identified, StrategyWeights())
        }
        assertEquals(TradeDirection.BUY, lastDecision.direction)
        org.junit.Assert.assertFalse(lastDecision.votes.isUnstableMarket)
    }

    @Test
    fun returnsHoldWhenMarketIsUnstableChoppy() {
        val engine = TradingStrategyEngine()
        var price = 1.0800
        var lastDecision = com.robizinho.ia.model.StrategyDecision(
            direction = TradeDirection.HOLD,
            confidence = 0.0,
            votes = com.robizinho.ia.model.StrategyVotes(0.0, 0.0, 0.0, 0.0, false, "")
        )
        val choppyDeltas = listOf(
            0.0005, -0.0005, 0.0005, -0.0005, 0.0006, -0.0006,
            0.0005, -0.0005, 0.0005, -0.0005, 0.0005, -0.0005
        )
        for (delta in choppyDeltas) {
            price += delta
            val identified = ScreenRecognitionState.Identified(
                packageName = "com.mercadotrade.app",
                brokerName = "Mercado Trade",
                assetSymbol = "EUR/USD",
                currentPrice = price,
                confidence = 0.95f,
                chartTrendDelta = 0.0,
                buttons = com.robizinho.ia.model.BrokerButtonBounds(null, null)
            )
            lastDecision = engine.evaluate(identified, StrategyWeights())
        }
        assertEquals(TradeDirection.HOLD, lastDecision.direction)
        org.junit.Assert.assertTrue(lastDecision.votes.isUnstableMarket)
    }
}
