# Robizinho IA — Projeto Android (Kotlin)

Este diretório contém o projeto Android nativo completo em Kotlin para o assistente flutuante **Robizinho IA**.

## Arquitetura Implementada
- **Foreground Service + Overlay Global** (`service/RobizinhoFloatingService.kt`):
  - Mantém o bot ativo em segundo plano ao trocar para outros apps (incluindo Mercado Trade).
  - Usa `SYSTEM_ALERT_WINDOW` (`TYPE_APPLICATION_OVERLAY`) com bolha arrastável e painel expansível/minimizável.
  - Botão **PARAR TUDO** interrompe imediatamente qualquer disparo automático.
- **Leitura de Tela** (`capture/ScreenCaptureManager.kt`):
  - Usa `MediaProjection` + `VirtualDisplay` + `ImageReader` + Google ML Kit OCR para extrair corretora, ativo, preço e localização dos botões.
  - Retorna `Unidentified` e bloqueia ordens sempre que os dados não forem confiáveis.
- **Execução Condicional Transparente** (`broker/BrokerConnector.kt`, `broker/RobizinhoAccessibilityService.kt`):
  - Prioriza integração via **API Oficial da Corretora** (`OfficialApiBrokerClient`).
  - Alternativamente, oferece automação visual via `AccessibilityService` somente mediante autorização explícita do usuário e conformidade com a corretora — sempre identificada como automação visual.
- **Inteligência e Segurança** (`strategy/TradingStrategyEngine.kt`, `safety/OrderExecutionGuard.kt`, `safety/SafetyPreferences.kt`):
  - Combina EMA (9/21), RSI (14) e estrutura de candles para decidir entre `COMPRAR`, `VENDER` ou `AGUARDAR`.
  - Inicia obrigatoriamente em **DEMO**; conta **REAL** exige autorização explícita.
  - Aplica limite de perda diária, limite de operações, chave de idempotência e política estrita de **nunca repetir ordem por falha de confirmação**.

## Como gerar o APK instalável
Este ambiente web não possui Android SDK / JDK instalados para compilar o `.apk` diretamente aqui. Para gerar o APK em sua máquina:
1. Abra a pasta `android-project` no **Android Studio** (Ladybug ou superior, JDK 17).
2. Aguarde a sincronização do Gradle (`compileSdk = 35`, `minSdk = 26`).
3. Execute `Build > Build Bundle(s) / APK(s) > Build APK(s)` ou via terminal:
   ```bash
   ./gradlew assembleDebug
   ```
4. O APK instalável será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Transparência de Testes na Mercado Trade
Nenhuma função foi executada dentro do aplicativo real da Mercado Trade neste ambiente web; toda a análise de OCR, coordenadas de botões e execução na corretora requer validação direta em dispositivo Android físico com o app da Mercado Trade instalado.
